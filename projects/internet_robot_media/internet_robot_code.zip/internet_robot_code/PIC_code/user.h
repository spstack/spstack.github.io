//littler

/******************************************************************************/
/* User Level #define Macros                                                  */
/******************************************************************************/
#define MAX_BUFFSIZE 20

#define BUFF_FULL 1
#define BUFF_EMPTY 0xFF
#define BUFF_NORMAL 0



/******************************************************************************/
/* User Structures                                                 */
/******************************************************************************/
//Buffer used for transmitting and recieving data
typedef struct _BUFFER {
  int head;
  int tail;
  unsigned char data[MAX_BUFFSIZE];
} BUFFER;


/******************************************************************************/
/* User Global Variable Declaration                                           */
/******************************************************************************/

// flags and global vars
unsigned int TIMEOUT_COUNTER;
unsigned char TIMEOUT;
unsigned char BYTE_RECEIVED;
unsigned char PACKET_SEQUENCE;
unsigned char COMMAND_DONE;

//BUFFERS
BUFFER RX_BUFF;
BUFFER TX_BUFF;
unsigned char COMMAND[4];

/******************************************************************************/
/* User Function Prototypes                                                   */
/******************************************************************************/

void InitApp(void);         /* I/O and Peripheral Initialization */
int BUFF_push(BUFFER*, char);
char BUFF_pop(BUFFER*);
int BUFF_status(BUFFER*);

//motor control functions
void motor_forward(unsigned char right_speed, unsigned char left_speed);
void motor_left(unsigned char right_speed, unsigned char left_speed);
void motor_right(unsigned char right_speed, unsigned char left_speed);
void motor_reverse(unsigned char right_speed, unsigned char left_speed);
void motor_stop();
void headlights_on();
void headlights_off();
