//Little robot
/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

#if defined(__XC)
    #include <xc.h>         /* XC8 General Include File */
#elif defined(HI_TECH_C)
    #include <htc.h>        /* HiTech General Include File */
#endif

#include "user.h"

/******************************************************************************/
/* User Functions                                                             */
/******************************************************************************/

/* <Initialize variables in user.h and insert code for user algorithms.> */

void InitApp(void)
{
    /* TODO Initialize User Ports/Peripherals/Project here */
    APFCON1bits.TXCKSEL = 0; //set TX to pin RB2
    APFCON0bits.RXDTSEL = 0; //set RX to pin RB1
    TRISB = 0x00; //init all PortB to outputs fo motor direction signals and headlight control
    TRISAbits.TRISA6 = 0; //debug LED1 -> not used in final version
    TRISAbits.TRISA7 = 0; //debug LED2 -> used as status LED in final version
    //RB5 = AIN1 - left
    //RB4 = AIN2 - left
    //RA6 = BIN1 - right
    //RA7 = BIN2 - right

    ANSELB = 0;
    ANSELA = 0;

    //Set up UART
    //    Interrupts on received byte. No interrupt on transmitted byte
    //    Baud rate is set at 19200
    TXSTAbits.TXEN = 1;
    TXSTAbits.SYNC = 0;
    TXSTAbits.BRGH = 1;  //high speed baud rate generator
    RCSTAbits.SPEN = 1;
    RCSTAbits.CREN = 1;
    TXSTAbits.TRMT = 1;
    BAUDCONbits.BRG16 = 0;
    SPBRGH = 0;
    SPBRGL = 50;    //baud rate of 19200


    //set up PWM output for right motor speed control
    //  Uses timer2 resource
    TRISAbits.TRISA3 = 1; //turn off output driver
    T2CONbits.T2CKPS = 1; //prescalar of 4 (FOSC/4 = 4MHz)
    T2CONbits.TMR2ON = 1; // turn timer 2 on
    PR2 = 25;            //set period to 38kHz (.0000263s)
    CCPTMRSbits.C3TSEL = 0; //CCP3 is based off of timer 2
    CCP3CONbits.CCP3M = 12; //set CCP3 to PWM mode
    CCP3CONbits.DC3B = 0;   //set the LSb's of the Duty Cycle
    CCPR3L = 0;          //set lower 8 bits of duty cycle reg. (at 50% duty cycle)
    TRISAbits.TRISA3 = 0; //turn on output driver

    //set up PWM output for left motor speed control
    //  Uses timer2 resource
    TRISAbits.TRISA4 = 1;
    CCPTMRSbits.C4TSEL = 0; //CCP4 is based off of timer 2
    CCP4CONbits.CCP4M = 12; //set CCP4 to PWM mode
    CCP4CONbits.DC4B = 0;   //set the LSb's of the Duty Cycle
    CCPR4L = 0;          //set lower 8 bits of duty cycle reg. (at 50% duty cycle)
    TRISAbits.TRISA4 = 0;

    //setup timeout timer (stops robot if no new commands)
    //  using timer4 resource
    T4CONbits.T4CKPS = 3; //use 64:1 prescalar for a 250kHz clock
    PR4 = 0xff;  //increment postscalar after timer overflows
    T4CONbits.T4OUTPS = 15; //1:16 postscalar THIS WILL YIELD A TIMER
    //INTERRUPT AFTER ~0.016 seconds!! Need to increment a variable counter to
    //get desired time of ~1 sec.



    //TODO: setup ADC inputs rof IR rangefinding sensors
    //--

    /* Enable interrupts */
    PIE3bits.TMR4IE = 1; //enable timeout timer interrupt
    PIE1bits.RCIE = 1;
    INTCONbits.GIE = 1;
    INTCONbits.PEIE = 1;
    ei();
}

//FUNCTIONS TO IMPLEMENT CIRCULAR BUFFER
int BUFF_push(BUFFER* buff, char c) {
  if((buff->tail + 1) % MAX_BUFFSIZE == buff->head) {
    return BUFF_FULL;
  } else {
    buff->data[buff->tail] = c;
    buff->tail = (buff->tail + 1) % MAX_BUFFSIZE;
  }
  return BUFF_NORMAL;
}

char BUFF_pop(BUFFER* buff) {
  char c = -1;
  if(buff->head == buff->tail) {
    return BUFF_EMPTY;
  } else {
    c = buff->data[buff->head];
    buff->head = (buff->head + 1) % MAX_BUFFSIZE;
  }
  return c;
}

int BUFF_status(BUFFER* buff) {
  if(buff->head == buff->tail) {
    return BUFF_EMPTY;
  } else if ((buff->tail + 1) % MAX_BUFFSIZE == buff->head) {
    return BUFF_FULL;
  } else {
    return BUFF_NORMAL;
  }
}


//motor control funtions
void motor_forward(unsigned char right_speed, unsigned char left_speed) {
    //left motor direction control
    LATBbits.LATB5 = 1;
    LATBbits.LATB4 = 0;
    //right motor dir control
    LATBbits.LATB7 = 1;
    LATBbits.LATB6 = 0;

    //set both PWM's to the specified speeds (scale to value b|t 0-25)
    CCPR3L = (left_speed+2) * 25 / 255;
    CCPR4L = (right_speed+2) * 25 / 255;

    LATAbits.LATA6 = 1; //debug LED
}

void motor_left(unsigned char right_speed, unsigned char left_speed) {
    //left motor direction control
    LATBbits.LATB5 = 0;
    LATBbits.LATB4 = 1;
    //right motor dir control
    LATBbits.LATB7 = 1;
    LATBbits.LATB6 = 0;

    //set both PWM's to the specified speeds
    CCPR3L = (left_speed+2) * 25 / 255;
    CCPR4L = (right_speed+2) * 25 / 255;

    LATAbits.LATA6 = 1; //debug LED
}

void motor_right(unsigned char right_speed, unsigned char left_speed) {
    //left motor direction control
    LATBbits.LATB5 = 1;
    LATBbits.LATB4 = 0;
    //right motor dir control
    LATBbits.LATB7 = 0;
    LATBbits.LATB6 = 1;

    //set both PWM's to the specified speeds
    CCPR3L = (left_speed+2) * 25 / 255;
    CCPR4L = (right_speed+2) * 25 / 255;

    LATAbits.LATA6 = 1; //debug LED
}

void motor_reverse(unsigned char right_speed, unsigned char left_speed) {
    //left motor direction control
    LATBbits.LATB5 = 0;
    LATBbits.LATB4 = 1;
    //right motor dir control
    LATBbits.LATB7 = 0;
    LATBbits.LATB6 = 1;

    //set both PWM's to the specified speeds
    CCPR3L = (left_speed+2) * 25 / 255;
    CCPR4L = (right_speed+2) * 25 / 255;

    LATAbits.LATA6 = 1; //debug LED
}

void motor_stop() {
    //left motor direction control
    LATBbits.LATB5 = 0;
    LATBbits.LATB4 = 0;
    //right motor dir control
    LATBbits.LATB7 = 0;
    LATBbits.LATB6 = 0;

    //set both PWM's to the specified speeds
    CCPR3L = 0;
    CCPR4L = 0;

    LATAbits.LATA6 = 0; //debug LED
}

void headlights_on() {
    LATBbits.LATB3 = 1;
}

void headlights_off() {
    LATBbits.LATB3 = 0;
}
