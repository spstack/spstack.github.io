//little robot

/* Files to Include                                                           */
/******************************************************************************/

#if defined(__XC)
    #include <xc.h>         /* XC8 General Include File */
#elif defined(HI_TECH_C)
    #include <htc.h>        /* HiTech General Include File */
#endif

//#include <stdint.h>        /* For uint8_t definition */
//#include <stdbool.h>       /* For true/false definition */

#include "system.h"        /* System funct/params, like osc/peripheral config */
#include "user.h"          /* User funct/params, such as InitApp */



/******************************************************************************/
/* Main Program                                                               */
/******************************************************************************/
void main(void)
{
    unsigned char next_byte;
    int TEMP_COUNTER = 0;

    /* Configure the oscillator for the device */
    ConfigureOscillator();
    /* Initialize I/O and Peripherals for application */
    InitApp();

    TIMEOUT = 0;
    TIMEOUT_COUNTER = 0;
    PACKET_SEQUENCE = 0;
    COMMAND_DONE = 0;


    //INIT outputs
    LATA = 0;
    LATB = 0;

    while(1)
    {

        //check for new UART bytes from RPi
        next_byte = BUFF_pop(&RX_BUFF);
        if(next_byte != BUFF_EMPTY) {
            BYTE_RECEIVED = 1;
            
            
        } else {
            BYTE_RECEIVED = 0;
        }

        //check for header byte from RPi
        if (BYTE_RECEIVED == 1 && next_byte == 0xfe) {
            COMMAND[0] = next_byte;
            PACKET_SEQUENCE = 1;
            BYTE_RECEIVED = 0;
        }

        //load data bytes into command as they come in
        if (BYTE_RECEIVED == 1 && (PACKET_SEQUENCE >= 1 && PACKET_SEQUENCE < 4)) {
            COMMAND[PACKET_SEQUENCE] = next_byte;
            BYTE_RECEIVED = 0;
            PACKET_SEQUENCE += 1;
        }

        if (PACKET_SEQUENCE == 4) {
            COMMAND_DONE = 1;
            PACKET_SEQUENCE = 0;

        }
        
        if (TEMP_COUNTER == -1) {
            BUFF_push(&TX_BUFF,0xaa); //test serial TX
            //LATAbits.LATA6 ^= 1;
        }


        if (COMMAND_DONE == 1) {
            COMMAND_DONE = 0;
            //take action associated w/ the command
            switch(COMMAND[1]) {
                case 0x00:
                    motor_stop();
                    break;
                case 0x01:
                    motor_forward(COMMAND[2],COMMAND[3]);
                    break;
                case 0x02:
                    motor_right(COMMAND[2],COMMAND[3]);
                    break;
                case 0x03:
                    motor_left(COMMAND[2],COMMAND[3]);
                    break;
                case 0x04:
                    motor_reverse(COMMAND[2],COMMAND[3]);
                    break;
                case 0x05:
                    headlights_on();
                    break;
                case 0x06:
                    headlights_off();
                    break;
                default:
                    motor_stop();
            }
        }

        //-------------------------TIMEOUT---------------------
        //if (TIMEOUT == 1) {
        //    motor_stop();
        //    TIMEOUT = 0;
        //}

        //-------------------------UART TX----------------------
        //if there are things to transmit. Send them
        if(BUFF_status(&TX_BUFF) != BUFF_EMPTY && TXSTAbits.TRMT == 1) {
            TXREG = BUFF_pop(&TX_BUFF);
        }

        TEMP_COUNTER += 1;
    }

}

