//little Robot

/******************************************************************************/
/*Files to Include                                                            */
/******************************************************************************/

#if defined(__XC)
    #include <xc.h>         /* XC8 General Include File */
#elif defined(HI_TECH_C)
    #include <htc.h>        /* HiTech General Include File */
#endif

#include "user.h"
/******************************************************************************/
/* Interrupt Routines                                                         */
/******************************************************************************/

/* Baseline devices don't have interrupts. Note that some PIC16's 
 * are baseline devices.  Unfortunately the baseline detection macro is 
 * _PIC12 */
//#ifndef _PIC12

void interrupt isr(void)
{
    char temp_char;

    if(RCIE && RCIF) {
        LATAbits.LATA6 ^= 1; //debug LED
        //If framing error...
        if (RCSTAbits.FERR) {
            temp_char = RCREG;
            RCSTAbits.SPEN = 0;
        } else { //put char into receive buffer
            temp_char = RCREG;
            BUFF_push(&RX_BUFF, temp_char);
        }
        RCIF = 0;
    }

    else if (TMR4IF && TMR4IE) {
        TIMEOUT_COUNTER += 1;
        if (TIMEOUT_COUNTER == 10) {
            TIMEOUT = 1;
            TIMEOUT_COUNTER = 0;
        }
        TMR4IF = 0;
    }

    else{
        PIR1 = 0;
        PIR2 = 0;
        PIR3 = 0;
        PIR4 = 0;
    }

}
//#endif


