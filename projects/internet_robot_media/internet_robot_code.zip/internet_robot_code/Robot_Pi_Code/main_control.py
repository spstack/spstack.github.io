#!/usr/bin/env python

#Main control file for the robot. This includes receiving commands from
# the interwebz and translating them into robot movement. 

import sys
import socket
import threading
import queue
import re
import time
import os
import subprocess

import robot_motor_control


"""
The format for commands to the server is COMMAND:arg1:arg2:...;
"""

class internetControl(threading.Thread):
    'Thread class that accepts and interprets commands from the C&C server'

    def __init__(self,CMD_Q):
        threading.Thread.__init__(self,name='internetControl')
        self._port = 2645
        self._host = '192.168.1.143'
        self._CONNSTRING = b'super-sweet-orange'
        self.command_re = re.compile(r'(forward|reverse|left|right|stop|camera_on|camera_off|headlights_on|headlights_off)((:[0-9a-zA-Z]+)*);')
        self._stopped = False
        self.CMD_Q = CMD_Q

    def parse_commands(self,data_buffer):
        commands = []
        for command in self.command_re.finditer(data_buffer):
            cmd = command.group(1)
            args = command.group(2).split(':')[1:]
            commands.append([cmd]+args) 
        return commands

    def stop(self):
        self._stopped = True
        self.sock.shutdown(socket.SHUT_RDWR)
        self.sock.close() 

    #this is the method that is run when this thread starts
    def run(self):
        while True:
            if self._stopped == True:
                return
            time.sleep(1)   #wait a sec between each connectoin attempt
            #first setup the tcp port that will receive commands
            self.sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
            #self.sock.setblocking(0)  # make socket non-blocking and timeout instead
            #self.sock.settimeout(5.0)
            try:
                self.sock.connect((self._host, self._port)) 
            except socket.error:
                print("Could not open connection to %s..." % (self._host))
                self.sock.close()
                del(self.sock)
                continue

            self.sock.sendall(self._CONNSTRING)
            try:
                recv_buffer = self.sock.recv(1024).decode()
            except:
                self.sock.close()
                print('could not receive bytes from socket...')
                continue
            print("Received " + recv_buffer + " from c&c server")
            if recv_buffer != "ok, got it":
                self.sock.shutdown(socket.SHUT_RDWR)
                self.sock.close()
                del(self.sock)
                continue

            #now start receiving commands and put them on the queue as they arrive
            recv_buffer = ''
            while True:
                try:
                    recv_buffer += self.sock.recv(8).decode()
                except:
                    print('receiving bytes caused error...reinitializing the socket')
                    break
                if not recv_buffer:
                    break # socket closed?
                commands = self.parse_commands(recv_buffer) 
                if len(commands) != 0:
                    recv_buffer = ''
                    for command in commands:
                        self.CMD_Q.put_nowait(command)
                if self._stopped == True:
                    return



#main function to coordinate all of the parts, and take action on incoming commands
def __main():
    #establish comms with micro that controls motor movement 
    robot = robot_motor_control.robotMotorControl()
    if robot.init_micro():
        print("Communication w/ micro established")
    else:
        print("Could not connect to micro...exiting")
        return

    #start the command receiving interface
    CMD_Q = queue.Queue()
    ic = internetControl(CMD_Q)
    ic.start() # run the command client thread 
    try:
        while True:
            cmd = CMD_Q.get(block=True,timeout=None)
            CMD_Q.task_done()
            cmd[1] = int(cmd[1])
            cmd[2] = int(cmd[2])
            print(cmd)
            if cmd[0] == 'forward':
                robot.forward(cmd[1],cmd[2])
            elif cmd[0] == 'reverse':
                robot.reverse(cmd[1],cmd[2])
            elif cmd[0] == 'right':
                robot.right(cmd[1],cmd[2])
            elif cmd[0] == 'left':
                robot.left(cmd[1],cmd[2])
            elif cmd[0] == 'camera_on': 
                subprocess.Popen(['/home/scott/programs/robot_control/mjpg-streamer-experimental/start_rpi_stream.bash'],shell=True)
            elif cmd[0] == 'camera_off':
                subprocess.Popen(['/home/scott/programs/robot_control/mjpg-streamer-experimental/stop_rpi_stream.bash'],shell=True)
            elif cmd[0] == 'headlights_on':
                robot.headlights_on()
            elif cmd[0] == 'headlights_off':
                robot.headlights_off()
            else:
                robot.stop()

    except KeyboardInterrupt:
        pass
    finally:
        ic.stop()
        raise

    


if __name__ == '__main__':
    __main()
