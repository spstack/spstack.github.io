export LD_LIBRARY_PATH=.
/home/scott/programs/robot_control/mjpg-streamer-experimental/mjpg_streamer -o "/home/scott/programs/robot_control/mjpg-streamer-experimental/output_http.so -w ./www" -i "/home/scott/programs/robot_control/mjpg-streamer-experimental/input_raspicam.so -x 640 -y 480 -fps 15 -vf -hf -ex night"
