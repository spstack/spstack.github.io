#!usr/bin/python
"""
This is the class used to control robot movement. It will communicate with another microcontroller
via UART to send movement commands.

packet format is as follows:
 initial handshake: host sends 0xaabbcc then micro responds with 0x55. After this, micro is ready to receove commands 


    Regular packet format: 
        1) 0xff   <-- packet header
        2) 0x--   <-- command byte
        3) 0x--   <-- arg1 (ex. right motor speed)
        3) 0x--   <-- arg2 (ex. left motor speed)



    commands:
        0x00    :   stop
        0x01    :   forward
        0x02    :   right
        0x03    :   left
        0x04    :   reverse


this might be extended someday to include other functions (pan tilt camera etc)
"""

#import RPi.GPIO as GPIO
import serial


class robotMotorControl():
    """ A class that handles all robot movement"""

    def __init__(self):
        #initialize the serial port and handshake w/ micro
        self.ser = serial.Serial('/dev/ttyAMA0',19200,timeout=1)
     

    def init_micro(self, attempts=10):
        """try to connect to micro 'attempts' times. Return True if connected"""
        """
        attempt = 0
        while (self.ser.read(1) != b'\x55'): 
            self.ser.write(b'\xaa\xbb\xcc')
            attempt += 1
            if attempt > attempts:
                return False
        """
        return True 

    
    def forward(self,right_speed,left_speed):
        packet = b''
        packet += b'\xfe' # command header
        packet +=b'\x01'  # forward command
        packet += bytes([right_speed]) # speed of right motor
        packet += bytes([left_speed])  # speed of left motor
        self.ser.write(packet)

    def reverse(self,right_speed,left_speed):
        packet = b''
        packet += b'\xfe' # command header
        packet +=b'\x04'  # reverse command
        packet += bytes([right_speed]) # speed of right motor
        packet += bytes([left_speed])  # speed of left motor
        self.ser.write(packet)


    def right(self,right_speed,left_speed):
        packet = b''
        packet += b'\xfe' # command header
        packet +=b'\x02'  # right command
        packet += bytes([right_speed]) # speed of right motor
        packet += bytes([left_speed])  # speed of left motor
        self.ser.write(packet)


    def left(self,right_speed,left_speed):
        packet = b''
        packet += b'\xfe' # command header
        packet +=b'\x03'  # left command
        packet += bytes([right_speed]) # speed of right motor
        packet += bytes([left_speed])  # speed of left motor
        self.ser.write(packet)


    def stop(self):
        packet = b''
        packet += b'\xfe' # command header
        packet += b'\x00'  # left command
        packet += bytes([0]) # speed of right motor
        packet += bytes([0])  # speed of left motor
        self.ser.write(packet)

    def headlights_on(self):
        packet = b''
        packet += b'\xfe' # command header
        packet += b'\x05'  # headlights on command
        packet += bytes([0]) # 
        packet += bytes([0]) # 
        self.ser.write(packet)

    def headlights_off(self):
        packet = b''
        packet += b'\xfe' # command header
        packet += b'\x06'  # headlights off command
        packet += bytes([0]) # 
        packet += bytes([0]) # 
        self.ser.write(packet)



    def close(self):
        self.ser.close()




#if called on it's own, test the robot motor functions
if __name__ == '__main__':
    import time
    robot = robotMotorControl()

    robot.init_micro()
    time.sleep(1)
    print("forward")
    robot.forward(254,254)
    time.sleep(1)
    print("reverse")
    robot.reverse(254,254)
    time.sleep(1)
    print("right")
    robot.right(254,254)
    time.sleep(1)
    print("left")
    robot.left(254,254)
    time.sleep(1)
    print("stop")
    robot.stop()
    
