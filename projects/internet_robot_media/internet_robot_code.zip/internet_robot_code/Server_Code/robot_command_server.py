#!/usr/bin/env python2

import sys
import socket,time
import threading
import Queue
import re
import SocketServer
import websocketserver


HOST = ''
ROBOT_PORT = 2645

CMD_Q = Queue.Queue()

VALID_CMDS = ['forward','reverse','left','right','stop','camera_on','camera_off', 'headlights_on', 'headlights_off']

class serverToRobot(threading.Thread):
	def __init__(self, conn, cmd_q, robot_number):
		self._name = "Robot_" + str(robot_number)
		self._conn = conn
		#self._conn.setblocking(0)
		#self._conn.settimeout(0.01)
		self.CMD_Q = cmd_q
		self._stopped = False
		threading.Thread.__init__(self,name=self._name)
		self.daemon = True	

	def formatCommand(self,command):
		formattedCommand = command[0]
		for cmd in command[1:]:
			formattedCommand += ':'+str(cmd)
		formattedCommand += ';'
		return formattedCommand

	def stop(self):
		self._stopped = True

	def run(self):
		while True:
			if self._stopped:
				break
			if not self.CMD_Q.empty():
				command = self.CMD_Q.get(False)
				self.CMD_Q.task_done()
				if type(command) == list:
					command = self.formatCommand(command)			
				if command.split(':')[0] not in VALID_CMDS:
					print "Invalid command: " + command
					continue
				print "CMD to send to robot: " + command
				try:
					self._conn.sendall(command)
				except socket.error:
					print "Closing connection to " + self._name
					print socket.error
					break
			


#class that hadles client (browser) communication through html5 websockets it will 
#hadle multiple connections and put recieved commands on the command queue (self.q)
class clientToServer(SocketServer.ThreadingTCPServer,threading.Thread):
	def __init__(self, server_address, q):
		threading.Thread.__init__(self)
		self.daemon = True	
		SocketServer.ThreadingTCPServer.__init__(self, server_address, websocketserver.WebSocketsHandler)
		self.q = q

	def run(self):
		self.serve_forever()


def __main():
	try:
		while True:
			time.sleep(2)

			#first setup robot listening port this socket will listen for new connection requests from robots
			s = socket.socket(socket.AF_INET,socket.SOCK_STREAM) #this is the socket to the robot 
			try:
				s.bind((HOST,ROBOT_PORT))
				s.listen(3)
			except socket.error:
				s.close()
				print('Could not bind robot listneing port...')
				continue


			#next set up client to server comms this should allow connections from multiple browsers at first
			clientControl = clientToServer(('',40001),CMD_Q)
			clientControl.start()


			#accept new connections from robots
			robot_connections = []
			while True:
				conn,addr = s.accept() #wait for a robot to connect before accepting any other commands
				print "got connection from robot: " + addr[0] + ':' + str(addr[1])
				

				#if the robot sends a recognized password, accept the connection
				#and start sending commands to the robot through the serverToRobot thread
				handshake = conn.recv(1024)
				if handshake != "super-sweet-orange":
					print("Not a recognized password!")	
					conn.shutdown(socket.SHUT_RDWR)
					conn.close()
					continue
				conn.sendall("ok, got it")

				#set up server to robot comms
				robotControl = serverToRobot(conn,CMD_Q,0)	
				robotControl.start()
				robot_connections.append(robotControl)
		
				#cleanup unused robot connections
				for robotThread in list(robot_connections):
					if not robotThread.is_alive():
						robot_connections.remove(robotThread)	

	except KeyboardInterrupt:
		pass
	except:
		raise
	finally:
		for robot_thread in robot_connections:
			robot_thread.stop()
		s.close()
		clientControl.server_close()


if __name__ == '__main__':
	__main()

