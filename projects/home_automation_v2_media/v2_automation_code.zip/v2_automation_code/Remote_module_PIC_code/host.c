#include <xc.h>
#include "main.h"
#include "host.h"
#include "zigbee.h"



void init_host() {
    
}

//send a completed data packet to the host
void host_send_packet(host_data_t *packet) {
    unsigned int datalength;
    datalength = (packet->data_length_H << 8) | packet->data_length_L;
    
    zigbee_send_message(ZIGBEE_COORDINATOR_ADDR_ZEROS, (char *)packet, datalength + 6 );
}


//send a temperature data packet
void host_send_temperature_packet(int temperature, unsigned char source_id) {
    temp_host_packet.start_byte = 0xAA;
    temp_host_packet.packet_type = TEMPERATURE_PACKET_TYPE;
    temp_host_packet.data_length_H = 0;
    temp_host_packet.data_length_L = 3;
    temp_host_packet.source_id = source_id;
    temp_host_packet.dst_id = 1; // baseboard destination
    temp_host_packet.payload_data.temperature_data.temperature_H = (char)((temperature >> 8) & 0x00FF);
    temp_host_packet.payload_data.temperature_data.temperature_L = (char)(temperature & 0x00FF); 
    
    host_send_packet(&temp_host_packet);
}

void host_send_humidity_packet(unsigned char humidity, unsigned char source_id) {
    temp_host_packet.start_byte = 0xAA;
    temp_host_packet.packet_type = HUMIDITY_PACKET_TYPE;
    temp_host_packet.data_length_H = 0;
    temp_host_packet.data_length_L = 3;
    temp_host_packet.source_id = source_id;
    temp_host_packet.dst_id = 1; // baseboard destination
    temp_host_packet.payload_data.humidity_data.relative_humidity = humidity;
    
    host_send_packet(&temp_host_packet);
}


//if the buffer is valid host data packet return packet type else return false (0)
char is_host_packet(char *data) {
    if (data[0] == 0xAA) {
        return data[1];
    }
    else {
        return 0;
    }
}


void host_handle_incoming_packet(host_data_t *packet) {
    //eventually, this will be used to handle IR control packets from the host PC
}