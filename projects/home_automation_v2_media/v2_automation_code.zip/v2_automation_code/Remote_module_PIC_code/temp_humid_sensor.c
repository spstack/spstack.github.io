#include <xc.h>
#include "main.h"
#include "peripherals.h"
#include "host.h"
#include "zigbee.h"
#include "temp_humid_sensor.h"

void init_temphumid_sensor() {
    COMMAND_IN_PROGRESS = 0;
    current_transaction_type = TEMP_HUMID_IDLE;
}


//%RH = (adcval / (2^14 - 2)) * 100
unsigned char convert_adc_to_humidity(unsigned int adcval) {
    long int temp;
    temp = (((long int)adcval * 100) / 16382);
    return (unsigned char)temp;
}

//TempC = (adcval / (2^14 - 2) * 165 - 40
int convert_adc_to_temperature(int adcval) {
    long int temp;
    temp = ( ((long int)adcval * 165) / 16382 - 40);
    return ((int)temp);
}

char temp_humid_check_status(unsigned char *humidity, int *temperature) {
    char buffer[5]; //temp sensor only returns 4 bytes of data
    char status;
    int temperature_adc;
    unsigned int humid_adc;
    
    if (COMMAND_IN_PROGRESS == 0) {
        return TEMP_HUMID_STATUS_INCOMPLETE;
    }
    if (current_transaction_type == TEMP_HUMID_WAIT) {
        if (TEMP_HUMID_TIMER >= 50) {
            start_temp_humid_read();
            current_transaction_type = TEMP_HUMID_READ;
            return TEMP_HUMID_STATUS_INCOMPLETE;
        }
    }
    //if transaction is complete copy temperature/humidity values
    status = I2C_check_completion(buffer);
    if (status == I2C_STATUS_COMPLETE) {
        if (current_transaction_type == TEMP_HUMID_MEASUREMENT_REQUEST) {
            current_transaction_type = TEMP_HUMID_WAIT;
            TEMP_HUMID_TIMER = 0;
        } else if (current_transaction_type == TEMP_HUMID_READ) {
            humid_adc = buffer[0] & ~TEMP_HUMID_STATUS_MASK;
            humid_adc = (humid_adc << 8) | buffer[1];
            temperature_adc = buffer[2];
            temperature_adc = (temperature_adc << 8) | buffer[3];
            temperature_adc = temperature_adc >> 2;

            *temperature = temperature_adc;
            //*temperature = convert_adc_to_temperature(temperature_adc);
            //*temperature = convert_C_to_F(*temperature);
            *humidity = convert_adc_to_humidity(humid_adc);
            COMMAND_IN_PROGRESS = 0;
            return TEMP_HUMID_STATUS_COMPLETE;
        } 
    } else if (status == I2C_STATUS_ERROR) {
        return TEMP_HUMID_STATUS_INCOMPLETE;
    }
    
    return TEMP_HUMID_STATUS_INCOMPLETE;
}

void start_temp_humid_conversion() {
    unsigned char *dummy_data = {0};
    I2C_start_write(0, TEMPHUMID_I2C_ADDRESS, dummy_data);
    current_transaction_type = TEMP_HUMID_MEASUREMENT_REQUEST;
    COMMAND_IN_PROGRESS = 1;
}


void start_temp_humid_read() {
    current_transaction_type = TEMP_HUMID_READ;
    COMMAND_IN_PROGRESS = 1;
    I2C_start_read(4, TEMPHUMID_I2C_ADDRESS);
}

//called from main to keep track of all temp humid activities
void temp_humid_tasks() {
    
    
    
    if (TEMP_HUMID_TIMER >= 60000) {
        TEMP_HUMID_MINUTE_TIMER += 1;
        TEMP_HUMID_TIMER = 0;

    }
    if (TEMP_HUMID_MINUTE_TIMER >= 15) {
        start_temp_humid_conversion();
        TEMP_HUMID_MINUTE_TIMER = 0;
        set_debug_led1_on();
        XBEE_SLEEP = 0; //bring xbee out of sleep
        XBEE_TIMER = 0;
    }

    //wait for zigbee to come out of sleep
    if (XBEE_TIMER > 2500) {
        if (temp_humid_check_status((unsigned char *)&humidity, (int *)&temperature) == TEMP_HUMID_STATUS_COMPLETE) {
            host_send_temperature_packet(temperature, SELF_SOURCE_ID);
            current_transaction_type = TEMP_HUMID_ZIGBEE_TEMP_TX;                       
        }
    }
    
    if (current_transaction_type == TEMP_HUMID_ZIGBEE_TEMP_TX) {
        if (zigbee_get_current_tx_status() == ZIGBEE_IDLE) {
            host_send_humidity_packet(humidity, SELF_SOURCE_ID);
            current_transaction_type = TEMP_HUMID_ZIGBEE_HUMID_TX; 
            XBEE_TIMER = 0;
        }
    }
    
    if (current_transaction_type == TEMP_HUMID_ZIGBEE_HUMID_TX) {
        if (zigbee_get_current_tx_status() == ZIGBEE_IDLE) {
            XBEE_SLEEP = 1;
            set_debug_led1_off();
            current_transaction_type = TEMP_HUMID_IDLE;
        }       
    }

    //check if device can go to sleep
    if (COMMAND_IN_PROGRESS) {
        READY_FOR_SLEEP = 0;
    }
}