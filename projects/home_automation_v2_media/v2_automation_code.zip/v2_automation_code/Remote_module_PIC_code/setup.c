#include <xc.h>

#include "main.h"
#include "setup.h"
#include "zigbee.h"
#include "temp_humid_sensor.h"

void initial_setup() {
    configure_oscillator();
    init_system_variables();
    
    
    //init peripherals
    init_timers();
    init_UART();
    init_I2C();
    init_GPIO();
    
    //higher level init
    init_zigbee();
    init_temphumid_sensor();
    
    enable_interrupts();
    
}


void configure_oscillator() {
    unsigned int i;
    
    //OSCCONbits.SCS = 3;  //set FOSC source to INTOSC
    OSCCONbits.IRCF = 0xF; //set oscillator to 16MHz postscalar
    
    //FOSC should now be 16MHz!! Wait for clk to stabilize...
    for (i=0; i<30000; i++);
    
}

void init_system_variables() {
    XBEE_JOINED = 0;
}

void enable_interrupts() {
    INTCONbits.GIE = 1;
    INTCONbits.PEIE = 1;
}

void disable_interrupts() {
    INTCONbits.GIE = 0;
    INTCONbits.PEIE = 0;
}

void init_GPIO() {
    ANSELA = 0; //configure all pins as digital
    ANSELB = 0;
    ANSELC = 0;
    
    TRISA = 0xFF;
    TRISB = 0xFF;
    TRISC = 0xFF;
    
    LED2TRIS = 0; //configure LEDs as output
    LED1TRIS = 0; 
    
    UART_RX_TRIS = 1;
    UART_TX_TRIS = 0;
    XBEE_SLEEP_TRIS = 0; //xbee sleep pin as output
    
    I2C_SDA_TRIS = 1;
    I2C_SCL_TRIS = 1;
           
    DEBUG_GPIO_TRIS = 0; //set as output
    
    LED1 = 0;       
    LED2 = 0;
    XBEE_SLEEP = 0; //put xbee out of sleep by default.
    
}

void init_I2C() {
    SSP1CONbits.SSPEN = 1; //enable the synchronous serial port
    SSP1CONbits.SSPM = 0x8; //I2C master mode
    SSP1ADD = 0x27; //set I2C clk to 100kHz
    
    SSP1CON3bits.PCIE = 1; //enable interrupt on stop condition
    SSP1CON3bits.SCIE = 1; //enable interrupt on start condition
    
    RB5PPS = 0x11; //set SDA output to RB5
    RB4PPS = 0x10; //set SCL output to RB4
    SSPCLKPPS = 0x0C;
    SSPDATPPS = 0x0D; //set SDA to RB5
    I2C_INTERRUPT_ENABLE = 1;
}


//initialize UART module
void init_UART() {
    TXSTAbits.SYNC = 0; //use async mode
    TXSTAbits.TXEN = 1; //enable transmitter
    TXSTAbits.CSRC = 1; //internal clk
    TXSTAbits.BRGH = 0;
    RC1STAbits.SPEN = 1; //enable receiver
    RC1STAbits.CREN = 1; //enable receiver
    
    
    BAUDCONbits.BRG16 = 0;  //use 16 bit baud rate control
    SPBRGL = 25; //set Baud rate to 9600
    SPBRGH = 0;
    
    //enable RX interrupt
    UART_RX_IE = 1;
    
    PPSLOCKbits.PPSLOCKED = 0;
    
    //assign UART TX to RC0
    ODCONCbits.ODC0 = 0;
    RC0PPS = 0x14;
    
    //assign UART RX to RC1
    RXPPS = 0x11;
}

void init_timers() {
    //first initialize timer 1 as the system tick clock
    //should interrupt every 1ms. Need to use timer 1 as it's 
    //the only one that can wake up the processor from sleep
    T1CONbits.TMR1CS = 3; //use the LFINTOSC (31kHz as timer clock)
    T1CONbits.T1CKPS = 0; //no prescalar
    T1CON |= 0x04; //do not sync timer1 to FOSC
    T1GCONbits.TMR1GE = 0; //don't gate timer 1
    SYSCLK_IE = 1;         //enable TMR1 interrupts
    
    //only need 32 timer cycles for 1 ms interrupt. Initialize the TMR1 value
    // to 0xFFFF - 31 = 0xFFE0 
    TMR1H = 0xFF;
    TMR1L = 0xE0;
    T1CONbits.TMR1ON = 1; //turn on timer
    
    
    
    
    
    
}





