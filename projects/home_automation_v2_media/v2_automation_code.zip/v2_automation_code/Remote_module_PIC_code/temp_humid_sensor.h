/* 
 * File:   temp_sensor.h
 * Author: Scott
 *
 * Created on November 20, 2015, 6:21 PM
 */

#ifndef TEMP_SENSOR_H
#define	TEMP_SENSOR_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#define TEMP_HUMID_STATUS_MASK 0xC0
#define TEMP_HUMID_STATUS_OK 0x00
#define TEMP_HUMID_STATUS_STALE 0x40
#define TEMP_HUMID_STATUS_COMMAND_MODE 0x80

#define TEMP_HUMID_STATUS_INCOMPLETE 0
#define TEMP_HUMID_STATUS_COMPLETE 1

//temp humid sensor stuff
#define TEMPHUMID_I2C_ADDRESS 0x4E //0x27 shifted left one

unsigned char COMMAND_IN_PROGRESS;
typedef enum {
    TEMP_HUMID_MEASUREMENT_REQUEST,
    TEMP_HUMID_WAIT,
    TEMP_HUMID_READ,
    TEMP_HUMID_ZIGBEE_TEMP_TX,   ///transimitted temperature wait for confirmation
    TEMP_HUMID_ZIGBEE_HUMID_TX,  // transmitted humidity wait for confirmation
    TEMP_HUMID_IDLE
}temp_humid_transaction_type;
temp_humid_transaction_type current_transaction_type;

int temperature;
unsigned char humidity;

void init_temphumid_sensor();
int convert_C_to_F(int); 
unsigned char convert_adc_to_humidity(unsigned int);
int convert_adc_to_temperature(int);
void start_temp_humid_conversion();
void start_temp_humid_read(); 
char temp_humid_check_status(unsigned char *, int *);
void temp_humid_tasks();

#endif	/* TEMP_SENSOR_H */

