/* 
 * File:   peripherals.h
 * Author: Scott
 *
 * Created on November 20, 2015, 6:20 PM
 */

#ifndef PERIPHERALS_H
#define	PERIPHERALS_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif


#define I2C_RW_BIT_MASK 0x01
#define I2C_STATUS_COMPLETE 1
#define I2C_STATUS_INCOMPLETE 0
#define I2C_STATUS_ERROR -1
#define I2C_READ 1
#define I2C_WRITE 0

typedef enum  {
    IDLE,
    START_SENT,
    ADDRESS_SENT,
    DATA_SENT,
    ACK_SENT,
    DONE,
    ERROR
} I2C_STATE_t;
I2C_STATE_t I2C_STATE;

unsigned int I2C_LENGTH;
unsigned char I2C_BUFFER[8];
unsigned char I2C_ADDRESS;
unsigned char I2C_READ_IDX;
char I2C_RW;

void timer_wait_ms(unsigned int);

void UART_tx_next_char();
void UART_send_char(char);
void UART_send_data(char *, unsigned int);
char UART_rx_next_byte();
char UART_rx_status();
void UART_flush_tx_buffer();

void set_debug_led1_on();
void set_debug_led1_off();
void set_debug_led2_on();
void set_debug_led2_off();


int BUFF_push(BUFFER *, char);
char BUFF_pop(BUFFER *);
int BUFF_status(BUFFER *);
 
void deep_copy(char *, char *, unsigned int);


char I2C_check_completion(char *);
void I2C_start_transaction();
void I2C_stop_transaction();
void I2C_start_read(unsigned char, unsigned char);
void I2C_start_write(unsigned char, unsigned char, unsigned char *);




#endif	/* PERIPHERALS_H */

