/* Scott Stack home automation remoteboard fw main.c file*/

#include <xc.h>

#include "main.h"
#include "setup.h"
#include "peripherals.h"
#include "host.h"
#include "temp_humid_sensor.h"
#include "zigbee.h"




int main(int argc, char** argv) {
    //char debug_msg[6] = {'h','e','l','l','o','!'};
    unsigned char i;
    
    
    
    //setup all HW
    initial_setup();
    
    //flash led1 to indicate reset
    for (i=0; i<5; i++) {
        set_debug_led1_on();
        timer_wait_ms(250);
        set_debug_led1_off();
        timer_wait_ms(250);
    }
    
    //this is the variable that will allow the device to go to sleep if set. 
    //The system tick clock tick will wake the CPU up out of sleep every 1ms.
    READY_FOR_SLEEP = 1;
   
    //-----------MAIN LOOP ---------------
    while (1) {
        READY_FOR_SLEEP = 1; //set ready to sleep by default. Have individual
        //sections set to 0 if need to stay awake
        
        
        //----------UART---------------
        //check UART characters to  tx
        UART_tx_next_char();
        
        
        //------------ZIGBEE RX-------------
        //check zigbee receive status and take action if complete
        if (zigbee_rx_byte_and_parse() == ZIGBEE_FRAME_COMPLETE) {
            handle_zigbee_message();
        }
        
        //------------ZIGBEE TX TIMEOUT----------
        if (zigbee_get_current_tx_status() != ZIGBEE_IDLE && XBEE_TIMER >= ZIGBEE_MSG_TIMEOUT_MS) {
            zigbee_tx_set_idle();
        }
        
        //-------TEMP HUMID SENSOR-------
        temp_humid_tasks();
        //}

        //DEBUG_GPIO ^= 1;
        if (READY_FOR_SLEEP) {
            SLEEP();
        }
    }
    
    
    
}

