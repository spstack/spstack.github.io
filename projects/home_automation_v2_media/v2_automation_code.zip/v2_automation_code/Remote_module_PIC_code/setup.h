/* 
 * File:   setup.h
 * Author: Scott
 *
 * Created on November 20, 2015, 6:18 PM
 */

#ifndef SETUP_H
#define	SETUP_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif



//functions
void initial_setup();
void configure_oscillator();
void init_system_variables();
void enable_interrupts();
void disable_interrupts();
void init_GPIO();
void init_I2C();
void init_UART();
void init_timers();


#endif	/* SETUP_H */

