/* 
 * File:   main.h
 * Author: Scott
 *
 * Created on November 20, 2015, 6:18 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

//button input stuff
#define BUTTON_INPUT_TRIS TRISAbits.TRISA5
#define BUTTON_INPUT PORTAbits.RA5


//LED pin declarations
#define LED2 PORTAbits.RA4
#define LED1 PORTAbits.RA2
#define LED2TRIS TRISAbits.TRISA4
#define LED1TRIS TRISAbits.TRISA2

#define DEBUG_GPIO LATBbits.LATB6
#define DEBUG_GPIO_TRIS TRISBbits.TRISB6

//UART pin mappings
#define UART_TX_TRIS TRISCbits.TRISC0
#define UART_RX_TRIS TRISCbits.TRISC1
#define UART_RX_IE PIE1bits.RCIE
#define UART_RX_IF PIR1bits.RCIF
#define UART_TX_RTS TXSTAbits.TRMT
#define XBEE_SLEEP_TRIS TRISCbits.TRISC2
#define XBEE_SLEEP PORTCbits.RC2


//IR stuff
#define IR_FET_GATE PORTCbits.RC5
#define IR_FET_GATE_TRIS TRISCbits.TRISC5


//Timer stuff
#define SYSCLK_IE PIE1bits.TMR1IE
#define SYSCLK_IF PIR1bits.TMR1IF


//I2C stuff
#define I2C_START_BIT_STATUS SSP1STATbits.S
#define I2C_STOP_BIT_STATUS SSP1STATbits.P
#define I2C_BUFFER_FULL_STATUS SSP1STATbits.BF
#define I2C_WRITE_COLLISION_DETECTED SSP1CON1bits.WCOL
#define I2C_RECEIVE_OVERFLOW SSP1CON1bits.SSPOV
#define I2C_ACK_STATUS SSP1CON2bits.ACKSTAT
#define I2C_ACK_DATA SSP1CON2bits.ACKDT
#define I2C_ACK_EN SSP1CON2bits.ACKEN
#define I2C_RECEIVE_ENABLE SSP1CON2bits.RCEN
#define I2C_STOP_CONDITION_ENABLE SSP1CON2bits.PEN
#define I2C_REPEATED_STOP_CONDITION_ENABLE SSP1CON2bits.RSEN
#define I2C_START_ENABLE SSP1CON2bits.SEN

#define I2C_INTERRUPT_ENABLE PIE1bits.SSP1IE
#define I2C_INTERRUPT_FLAG PIR1bits.SSP1IF

#define I2C_SDA_TRIS TRISBbits.TRISB5
#define I2C_SCL_TRIS TRISBbits.TRISB4


//host packet definitions
#define SELF_SOURCE_ID SOURCE_ID_DEVICE2  //CHANGE THIS BETWEEN MODULES!

//buffer size declarations
#define MAX_BUFFSIZE 36
#define BUFF_FULL 1
#define BUFF_EMPTY 0xFF
#define BUFF_NORMAL 0


//Buffer used for transmitting and recieving data
typedef struct _BUFFER {
  unsigned int head;
  unsigned int tail;
  unsigned char data[MAX_BUFFSIZE];
} BUFFER;




//global variables
unsigned int GENERAL_TIMER;
unsigned int DEBUG_TIMER;
unsigned int TEMP_HUMID_TIMER;
unsigned int TEMP_HUMID_MINUTE_TIMER;
unsigned char XBEE_JOINED;
unsigned int XBEE_TIMER;

unsigned char READY_FOR_SLEEP;


//uart
BUFFER RX_BUFF;
BUFFER TX_BUFF;



#endif	/* MAIN_H */

