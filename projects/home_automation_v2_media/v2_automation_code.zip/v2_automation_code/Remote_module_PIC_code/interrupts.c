#include <xc.h>
#include "main.h"
#include "peripherals.h"



void interrupt isr() {
    
    //-------------system clk that ticks every 1ms-----------
    if (SYSCLK_IE && SYSCLK_IF) {
        GENERAL_TIMER += 1;
        DEBUG_TIMER += 1;
        TEMP_HUMID_TIMER += 1;
        XBEE_TIMER += 1;
        
        SYSCLK_IF = 0;
        TMR1H = 0xFF;
        TMR1L = 0xE0; //re-initialize timer to 1ms
    }
    
    //---------------uart rx interrupt----------------
    else if (UART_RX_IE && UART_RX_IF) {
        char tempchar;
        if (RC1STAbits.FERR || RC1STAbits.OERR) {
            tempchar = RCREG;
            RC1STAbits.FERR = 0;
            RC1STAbits.OERR = 0;
        } else {
            tempchar = RCREG;
            BUFF_push(&RX_BUFF, tempchar);
        }
        UART_RX_IF = 0;
       
    }
    
    //-----------------I2C interrupts ---------------------
    else if (I2C_INTERRUPT_ENABLE && I2C_INTERRUPT_FLAG) {
        I2C_INTERRUPT_FLAG = 0;
        
        if (I2C_STATE == IDLE) {
            //error? shouldn't happen...clear all error bits
            I2C_BUFFER_FULL_STATUS = 0;
            I2C_WRITE_COLLISION_DETECTED = 0;
            I2C_RECEIVE_OVERFLOW = 0;
        } 
        
        //start condition finished...send address
        else if (I2C_STATE == START_SENT) {
            SSP1BUF = I2C_ADDRESS; //load address w/ R/W bit and send it
            I2C_STATE = ADDRESS_SENT;
        } 
        
        //address finished...check ack and send/receive data
        else if (I2C_STATE == ADDRESS_SENT) {
            if (I2C_ACK_STATUS == 0) {
                if (I2C_RW == I2C_READ) {
                    I2C_RECEIVE_ENABLE = 1;
                    I2C_STATE = DATA_SENT;
                } else {
                    if (I2C_READ_IDX == I2C_LENGTH) {
                        I2C_stop_transaction(); //send stop condition
                        I2C_STATE = DONE;
                    } else {
                        SSP1BUF = I2C_BUFFER[I2C_READ_IDX];
                        I2C_READ_IDX += 1;
                        I2C_STATE = DATA_SENT;

                    }
                }
            } else {
                I2C_STATE = ERROR; //nack received
            }
        }
        
        //data sent/received...check ack, or send ack and get/load new data
        else if (I2C_STATE == DATA_SENT) {
            if (I2C_ACK_STATUS == 0) {
                if (I2C_RW == I2C_READ) {  //if read
                    I2C_BUFFER[I2C_READ_IDX] = SSP1BUF;
                    I2C_READ_IDX += 1;
                    
                    if (I2C_READ_IDX == I2C_LENGTH) {
                        I2C_ACK_DATA = 1;
                        I2C_ACK_EN = 1;
                    } else {
                        I2C_ACK_DATA = 0;
                        I2C_ACK_EN = 1;
                        
                    }
                    I2C_STATE = ACK_SENT;
                    
                } else if (I2C_RW == I2C_WRITE) { //if write
                    if (I2C_READ_IDX == I2C_LENGTH) {
                        I2C_stop_transaction(); //send stop condition
                        I2C_STATE = DONE;
                    }
                    SSP1BUF = I2C_BUFFER[I2C_READ_IDX];
                    I2C_READ_IDX += 1;
                    
                }
            } else {
                I2C_STATE = ERROR; //NACK received! stop transmission
            }
        }
        
        //now ack has been clocked out and need to enable receiver
        //only get to this state during a read.
        else if (I2C_STATE == ACK_SENT) {
            if (I2C_RW == I2C_READ) {
                if (I2C_READ_IDX == I2C_LENGTH) {
                        I2C_ACK_DATA = 1;
                        I2C_ACK_EN = 0;
                        I2C_stop_transaction(); //send stop condition
                        I2C_STATE = DONE;
                } else {
                    I2C_RECEIVE_ENABLE = 1;
                    I2C_ACK_DATA = 1;
                    I2C_ACK_EN = 0;
                    I2C_STATE = DATA_SENT;
                }
            } else {
                I2C_STATE = ERROR;
            }
            
        }
        
        else {
            //error? shouldn't happen...clear all error bits
            I2C_BUFFER_FULL_STATUS = 0;
            I2C_WRITE_COLLISION_DETECTED = 0;
            I2C_RECEIVE_OVERFLOW = 0;
        }
        
    }
    
    else {
        PIR1 = 0;
        PIR2 = 0;
        PIR3 = 0;
        
        
    }
    
}
