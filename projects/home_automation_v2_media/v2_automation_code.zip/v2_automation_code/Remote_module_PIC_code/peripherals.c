#include <xc.h>
#include "main.h"
#include "peripherals.h"



//-----------------------------------------------------------------
//--------------            TIMERS           ------------------------
//-----------------------------------------------------------------
void timer_wait_ms(unsigned int time) {
    GENERAL_TIMER = 0;
    
    while(GENERAL_TIMER < time);
}

//-----------------------------------------------------------------
//--------------            UART           ------------------------
//-----------------------------------------------------------------

void UART_tx_next_char() {
    unsigned char temp;
    if (BUFF_status(&TX_BUFF) != BUFF_EMPTY) {
        READY_FOR_SLEEP = 0; //keep device alive if there are UART things to send
        if (UART_TX_RTS == 1) {
            temp = BUFF_pop(&TX_BUFF);
            TXREG = temp;
        }
    } else if (UART_TX_RTS == 0) { 
        READY_FOR_SLEEP = 0; //also keep out of sleep if UART is not done transmitting
    }
}

void UART_send_char(char to_send) {
    BUFF_push(&TX_BUFF, to_send);
}

void UART_send_data(char *buffer, unsigned int length) {
    unsigned int i;
    
    for (i=0; i<length; i++) {
        UART_send_char(buffer[i]);
    }
}

char UART_rx_next_byte() {
    return BUFF_pop(&RX_BUFF);
}

char UART_rx_status() {
    return BUFF_status(&RX_BUFF);
}

char UART_tx_status() {
    return BUFF_status(&TX_BUFF);
}

void UART_flush_tx_buffer() {
    while (UART_tx_status() != BUFF_EMPTY) {
        UART_tx_next_char();
    }
}

//-----------------------------------------------------------------
//--------------             I2C          ------------------------
//-----------------------------------------------------------------
char I2C_check_completion(char *return_buffer) {
    if (I2C_STATE == IDLE) {
        return I2C_STATUS_INCOMPLETE;
    } else if (I2C_STATE == DONE && ((I2C_ADDRESS & I2C_RW_BIT_MASK) == 1)) { //if read done
        deep_copy(I2C_BUFFER, return_buffer, I2C_LENGTH);
        return I2C_STATUS_COMPLETE;
    } else if (I2C_STATE == DONE && ((I2C_ADDRESS & I2C_RW_BIT_MASK) == 0)) { // if write done
        return I2C_STATUS_COMPLETE;
    } else if (I2C_STATE == ERROR) {
        I2C_STATE = IDLE;
        return I2C_STATUS_ERROR;
    }
    return I2C_STATUS_INCOMPLETE; //if any other state, transaction is still in progress
}

void I2C_start_transaction() {
    I2C_START_ENABLE = 1;
}

void I2C_stop_transaction() {
    I2C_STOP_CONDITION_ENABLE = 1;
}

//initiate an I2C read sequence. read num_bytes and store data in I2C_READ_BUFFER
void I2C_start_read(unsigned char num_bytes, unsigned char address) {
    I2C_LENGTH = num_bytes;
    I2C_ADDRESS = address | 0x01;  //set RW bit to indicate read
    I2C_RW = I2C_READ;
    I2C_READ_IDX = 0;
    I2C_start_transaction();
    I2C_STATE = START_SENT;
}

void I2C_start_write(unsigned char num_bytes, unsigned char address, unsigned char *data) {
    I2C_LENGTH = num_bytes;
    I2C_READ_IDX = 0;
    I2C_ADDRESS = address & (~I2C_RW_BIT_MASK); //clear RW bit to indicate write
    I2C_RW = I2C_WRITE;
    deep_copy(data, I2C_BUFFER, num_bytes); //copy write data
    
    I2C_start_transaction();
    I2C_STATE = START_SENT;
}






//-----------------------------------------------------------------
//--------------           GPIOS          ------------------------
//-----------------------------------------------------------------

void set_debug_led1_on() {
    LED1 = 1;
}

void set_debug_led1_off() {
    LED1 = 0;
}

void set_debug_led2_on() {
    LED2 = 1;
}

void set_debug_led2_off() {
    LED2 = 0;
}


//-----------------------------------------------------------------
//--------------           BUFFERS           ------------------------
//-----------------------------------------------------------------

//FUNCTIONS TO IMPLEMENT CIRCULAR BUFFER
int BUFF_push(BUFFER *buff, char c) {
  if((buff->tail + 1) % MAX_BUFFSIZE == buff->head) {
    return BUFF_FULL;
  } else {
    buff->data[buff->tail] = c;
    buff->tail = (buff->tail + 1) % MAX_BUFFSIZE;
  }
  return BUFF_NORMAL;
}

char BUFF_pop(BUFFER *buff) {
  char c = -1;
  if(buff->head == buff->tail) {
    return BUFF_EMPTY;
  } else {
    c = buff->data[buff->head];
    buff->head = (buff->head + 1) % MAX_BUFFSIZE;
  }
  return c;
}

int BUFF_status(BUFFER *buff) {
  if(buff->head == buff->tail) {
    return BUFF_EMPTY;
  } else if ((buff->tail + 1) % MAX_BUFFSIZE == buff->head) {
    return BUFF_FULL;
  } else {
    return BUFF_NORMAL;
  }
}

//-----------------------------------------------------------------
//--------------            MEMORY BUFFERS      ------------------------
//-----------------------------------------------------------------
void deep_copy(char *src, char *dst, unsigned int length) {
    unsigned int i;
    for (i=0; i<length; i++) {
        dst[i] = src[i];
    }
}