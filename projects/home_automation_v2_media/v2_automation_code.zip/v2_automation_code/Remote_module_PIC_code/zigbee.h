/* 
 * File:   zigbee.h
 * Author: Scott
 *
 * Created on November 20, 2015, 6:21 PM
 */

#ifndef ZIGBEE_H
#define	ZIGBEE_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#define ZIGBEE_FRAME_COMPLETE 1
#define ZIGBEE_FRAME_INCOMPLETE 0

#define MAX_ZIGBEE_ADDRESSES 10

#define ZIGBEE_SOF 0x7E

#define ZIGBEE_TX_REQUEST_TYPE 0x10
#define ZIGBEE_RX_PACKET_TYPE 0x90
#define ZIGBEE_TX_STATUS_TYPE 0x8B
#define ZIGBEE_MODEM_STATUS_TYPE 0x8A

#define ZIGBEE_TX_REQUEST_64bit_ADDR 0x00
#define ZIGBEE_TX_REQUEST_16bit_ADDR 0x01
#define ZIGBEE_AT_COMMAND 0x08

#define ZIGBEE_STATUS_JOINED_NETWORK 0x02
#define ZIGBEE_STATUS_HARDWARE_RESET 0x00

#define ZIGBEE_TX_STATUS_SUCCESS 0x00
#define ZIGBEE_TX_STATUS_NOT_JOINED_TO_NEXTWORK 0x22

#define ZIGBEE_MSG_TIMEOUT_MS 3500

// zigbee API frames
typedef struct _zigbee_rx_frame {
    char SOF;
    char length_u;
    char length_l;
    char packet_type;
    union _rest_of_packet {
        struct _rx_packet {
            char address_64[8];
            char address_16[2];
            char rx_options;
            char data[15];
        } rx_packet;
        
        struct _modem_status {
            char status;
        } modem_status;
        
        struct _transmit_status {
            char frame_id;
            char address_16[2];
            char transmit_retry_count;
            char delivery_status;
            char discovery_status;
        } transmit_status;
    } ptype;
    char checksum;

} zigbee_rx_frame_t;


typedef enum _zigbee_tx_status {
    ZIGBEE_IDLE,
    ZIGBEE_SENDING_MESSAGE,
    ZIGBEE_WAITING_RESPONSE,
    ZIGBEE_TX_ERROR,  
} zigbee_status;

void init_zigbee();
unsigned char zigbee_send_message(char [], char *, int);
int zigbee_rx_byte_and_parse();
int zigbee_fill_rx_packet(char);
int zigbee_fill_modem_status_packet(char);
int zigbee_fill_tx_status_packet(char);
void zigbee_copy_frame(zigbee_rx_frame_t *, zigbee_rx_frame_t *);
void zigbee_tx_set_idle();
zigbee_status zigbee_get_current_tx_status();
void handle_zigbee_message();


//variables
unsigned char next_frame_id;
unsigned char cur_frame_id;
unsigned char zigbee_tx_retries;

char ZIGBEE_DEVICE1_ADDR[8] = {0x00, 0x13, 0xA2, 0x00, 0x40, 0xD8, 0xD1, 0x42}; //0x0013A20040D8D142
char ZIGBEE_DEVICE2_ADDR[8] = {0x00, 0x13, 0xA2, 0x00, 0x40, 0xE8, 0x73, 0xA1};//0013A20040E873A1
char ZIGBEE_DEVICE3_ADDR[8] = {0x00, 0x13, 0xA2, 0x00, 0x40, 0xE8, 0x73, 0xD2}; //0x0013A20040E873D2
char ZIGBEE_COORDINATOR_ADDR_ZEROS[8] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}; //0x0000000000000000
char ZIGBEE_COORDINATOR_ADDR[8] = {0x00, 0x13, 0xa2, 0x00, 0x40, 0xE6, 0xEC, 0x59}; //0x0013A20040E6EC59

//position in array has to equal the source_id of the address
char *ZIGBEE_SOURCE_ID_ADDR_MAPPING[MAX_ZIGBEE_ADDRESSES];



zigbee_status zigbee_cur_tx_status;

unsigned char zigbee_cur_rx_frame_idx;
unsigned int zigbee_cur_rx_frame_length;
unsigned int zigbee_cur_rx_frame_data_idx;
zigbee_rx_frame_t zigbee_temp_rx_frame;
zigbee_rx_frame_t zigbee_cur_frame; //current working frame


#endif	/* ZIGBEE_H */

