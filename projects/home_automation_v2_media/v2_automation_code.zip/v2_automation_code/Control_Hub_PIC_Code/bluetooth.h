/* 
 * File:   bluetooth.h
 * Author: Scott
 *
 * Created on August 21, 2015, 12:03 PM
 */

#ifndef BLUETOOTH_H
#define	BLUETOOTH_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

void init_bluetooth();


#endif	/* BLUETOOTH_H */

