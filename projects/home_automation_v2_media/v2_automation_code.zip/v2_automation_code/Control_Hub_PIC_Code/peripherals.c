#include <xc.h>
#include "main.h"
#include "peripherals.h"
#include "setup.h"






//-----------------------------------------------------------------
//--------------            TIMER          ------------------------
//-----------------------------------------------------------------

//sleep for the specified number of ms
void timer_wait_ms(unsigned int time_ms) {
    GENERAL_TIMER = 0;
    //interrupt routine will increment GENERAL_TIMER every 1ms
    while (GENERAL_TIMER < time_ms);
}

void timer_wait_us(unsigned int time_us) {
    //do stuff
}



//-----------------------------------------------------------------
//--------------            UART           ------------------------
//-----------------------------------------------------------------


void UART1_send_next_char() {
    if (BUFF_status(&TX1_BUFF) != BUFF_EMPTY) {
        if (TXSTAbits.TRMT != 0) { //wait until previous byte is sent
            UART1_TX_REG = BUFF_pop(&TX1_BUFF);
        }
    }
}

void UART1_send_char(char toSend) {
    BUFF_push(&TX1_BUFF, toSend);
}


void UART2_send_next_char() {
    if (BUFF_status(&TX2_BUFF) != BUFF_EMPTY) {
        if (TXSTA2bits.TRMT != 0) { //wait until previous byte is sent
            UART2_TX_REG = BUFF_pop(&TX2_BUFF);
        }
    }
}

void UART2_send_char(char toSend) {
    BUFF_push(&TX2_BUFF, toSend);
}


void UART1_send_data(char *buffer, int length) {
    unsigned int i;
    
    for (i=0; i<length; i++) {
        UART1_send_char(buffer[i]);
    }
}

void UART2_send_data(char *buffer, int length) {
    unsigned int i;
    for (i=0; i<length; i++) {
        UART2_send_char(buffer[i]);
    }
}

char UART1_rx_status() {
    return BUFF_status(&RX1_BUFF);
}

char UART1_rx_next_byte() {
    return BUFF_pop(&RX1_BUFF);
}

char UART2_rx_status() {
    return BUFF_status(&RX2_BUFF);
}

char UART2_rx_next_byte() {
    return BUFF_pop(&RX2_BUFF);
}


//-----------------------------------------------------------------
//--------------            MEMORY BUFFERS      ------------------------
//-----------------------------------------------------------------
void deep_copy(char *src, char *dst, unsigned int length) {
    unsigned int i;
    for (i=0; i<length; i++) {
        dst[i] = src[i];
    }
}



//-----------------------------------------------------------------
//--------------        ADC FUNCTIONS    -------------------------
//-----------------------------------------------------------------
int analog_read(char pinnum) {
    
}



//-----------------------------------------------------------------
//--------------        GPIO FUNCTIONS    -------------------------
//-----------------------------------------------------------------
void set_debug_led_on() {
    DEBUG_LED = 1;
}

void set_debug_led_off() {
    DEBUG_LED = 0;
}

//set the select pin on the switch to switch the source of the UART to either
//the bluetooth module or the host PC
void set_uart2_source_sel(enum uart2_source_t source) {
    if (source == UART2_HOST_PC) {
        UART_SOURCE_SEL_PIN = 0;
    } 
    else if (source == UART2_BT) {
        UART_SOURCE_SEL_PIN = 1;
    }
    
}