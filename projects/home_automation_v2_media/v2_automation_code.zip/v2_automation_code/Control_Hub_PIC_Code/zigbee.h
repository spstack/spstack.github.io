/* 
 * File:   zigbee.h
 * Author: Scott
 *
 * Created on August 21, 2015, 11:53 AM
 */

#ifndef ZIGBEE_H
#define	ZIGBEE_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif


//network - fatscubatankoctopus

#define ZIGBEE_FRAME_COMPLETE 1
#define ZIGBEE_FRAME_INCOMPLETE 0

#define MAX_ZIGBEE_ADDRESSES 10
#define ZIGBEE_CURRENT_DEVICE_ID ZIGBEE_COORDINATOR_ADDR

#define ZIGBEE_SOF 0x7E

#define ZIGBEE_TX_REQUEST_TYPE 0x10
#define ZIGBEE_RX_PACKET_TYPE 0x90
#define ZIGBEE_TX_STATUS_TYPE 0x8B

#define ZIGBEE_TX_REQUEST_64bit_ADDR 0x00
#define ZIGBEE_TX_REQUEST_16bit_ADDR 0x01
#define ZIGBEE_AT_COMMAND 0x08


// zigbee API frames
typedef struct _zigbee_rx_frame {
    char SOF;
    char length_u;
    char length_l;
    char packet_type;
    char address_64[8];
    char address_16[2];
    char rx_options;
    char data[MAX_BUFFSIZE];
    char checksum;

} zigbee_rx_frame_t;



void init_zigbee();
void zigbee_send_message(char [], char *, int);
int zigbee_rx_byte_and_parse();
void zigbee_copy_frame(zigbee_rx_frame_t *, zigbee_rx_frame_t *);
void zigbee_forward_host_packet(char *);


//variables
unsigned char frame_id;
char ZIGBEE_DEVICE1_ADDR[8] = {0x00, 0x13, 0xA2, 0x00, 0x40, 0xD8, 0xD1, 0x42}; //0x0013A20040D8D142
char ZIGBEE_DEVICE2_ADDR[8] = {0x00, 0x13, 0xA2, 0x00, 0x40, 0xE8, 0x73, 0xA1}; //0x0013A20040E873A1
char ZIGBEE_DEVICE3_ADDR[8] = {0x00, 0x13, 0xA2, 0x00, 0x40, 0xE8, 0x73, 0xD2}; //0x0013A20040E873D2
char ZIGBEE_COORDINATOR_ADDR_ZEROS[8] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}; //0x0000000000000000
char ZIGBEE_COORDINATOR_ADDR[8] = {0x00, 0x13, 0xa2, 0x00, 0x40, 0xE6, 0xEC, 0x59}; //0x0013A20040E6EC59

//position in array has to equal the source_id of the address
char *ZIGBEE_SOURCE_ID_ADDR_MAPPING[MAX_ZIGBEE_ADDRESSES];


unsigned char zigbee_cur_rx_frame_idx;
unsigned int zigbee_cur_rx_frame_length;
unsigned int zigbee_cur_rx_frame_data_idx;
zigbee_rx_frame_t zigbee_temp_rx_frame;
zigbee_rx_frame_t zigbee_cur_frame; //current working frame

#endif	/* ZIGBEE_H */

