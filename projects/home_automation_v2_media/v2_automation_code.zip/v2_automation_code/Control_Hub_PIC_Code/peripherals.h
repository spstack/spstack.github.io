/* 
 * File:   peripherals.h
 * Author: Scott
 *
 * Created on September 7, 2015, 4:24 PM
 */

#ifndef PERIPHERALS_H
#define	PERIPHERALS_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

enum uart2_source_t {
    UART2_HOST_PC,
    UART2_BT
};



//timer functions
void timer_wait_ms(unsigned int);
void timer_wait_us(unsigned int);

//uart functions
char UART1_get_next_char();
char UART2_get_next_char();
void UART1_send_next_char();
void UART1_send_char(char);
void UART2_send_next_char();
void UART2_send_char(char);
void UART1_send_data(char *, int);
void UART2_send_data(char *, int);
char UART1_rx_status();
char UART1_rx_next_byte();
char UART2_rx_status();
char UART2_rx_next_byte();

//memory functions
void deep_copy(char *, char *, unsigned int);

//adc functions
int analog_read(char);


//GPIO functions
void set_debug_led_on();
void set_debug_led_off();
void set_uart2_source_sel(enum uart2_source_t);


#endif	/* PERIPHERALS_H */

