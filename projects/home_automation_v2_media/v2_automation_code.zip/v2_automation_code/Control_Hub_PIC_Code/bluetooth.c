#include <xc.h>
#include "bluetooth.h"


void init_bluetooth() {
    
}
