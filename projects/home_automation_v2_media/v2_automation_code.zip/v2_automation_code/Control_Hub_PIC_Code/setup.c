#include <xc.h>
#include "main.h"
#include "setup.h"
#include "bluetooth.h"
#include "pi.h"
#include "temp_sensor.h"
#include "zigbee.h"
#include "interrupts.h"
#include "rf_control.h"

void initial_setup() {
    configure_oscillator();

    init_system_variables();
    init_GPIO();
    init_UART();
    init_SPI();
    init_timers();
    init_interrupts();
    init_adc();
    
    //higher level initialization
    init_bluetooth();
    init_pi();
    init_zigbee();
    init_tempSensor();
    rf_control_init();

}


void init_system_variables() {
    UART1_RX_FLAG = 0;
    UART1_TX_FLAG = 0;
    
    // temperature
    TEMPERATURE_TIMER = 0;
    TEMPERATURE_MINUTE_TIMER = 0;
    TEMPERATURE_CONVERSION_DONE_FLAG = 0;

}


void configure_oscillator() {
    unsigned int i;

#ifdef PIC18F46J50
    OSCCONbits.IRCF = 7; //set internal oscillator to 8MHz
    for(i=0; i<60000; i++); //wait
    OSCTUNEbits.PLLEN = 1; //enable PLL
    for(i=0; i<60000; i++); //wait for PLL lock
    for(i=0; i<60000; i++); //wait for PLL lock (2ms)

    //oscillator frequency should now be 48MHz
#endif

#ifdef PIC16F1847
    OSCCONbits.IRCF = 15; //use 16MHz internal clock
    for(i=0;i<20000;i++);  //wait until clock is stable before doing anything...
#endif

    
}


void init_GPIO() {
    DEBUG_LED_TRIS = 0; //set debug LED to output
    DEBUG_LED = 0;
    RX_LED_TRIS = 0; //set rx led to output
    RX_LED = 0;
    
    RF_PIN_TRIS = 0;
    
    UART_SOURCE_SEL_PIN_TRIS = 0;
    UART_SOURCE_SEL_PIN = 0; //set UART source to bluetooth module
    
}


void init_adc() {
#ifdef PIC18F46J50
    ANCON0 = 0xFF;  //configure all GPIOs as digital to begin with
    ANCON1 = 0xFF;

    //setup ADC
    TEMP_SENSOR_PIN_TRIS = 1; //set pin as input
    TEMP_SENSOR_ANSEL = 0;  // set AN9 to analog input

    ADCON0bits.CHS = 9; //select channel 9
    ADCON0bits.VCFG1 = 0; //use VSS as reference
    ADCON0bits.VCFG0 = 0; //use VDD as + reference
    
    ADCON1bits.ADFM = 0; //left justify the result
    ADCON1bits.ADCS = 6;   //select Fosc/64 as conversion clock source
    ADCON0bits.ADON = 1; //turn on ADC module
    
    
#endif   

#ifdef PIC16F1847
    ANSELA = 0;
    ANSELB = 0;
    
    //setup ADC
    TEMP_SENSOR_PIN_TRIS = 1; //set pin as input
    TEMP_SENSOR_ANSEL = 1;    //set temp sensor pin to analog input
    
    //setup fixed voltage reference
    FVRCONbits.ADFVR = 2; //fixed reference voltage is set to 2.048V
    FVRCONbits.FVREN = 1;
    
    ADCON0bits.CHS = 0; //choose AN0 to connect to ADC
    ADCON1bits.ADNREF = 0;  //choose VSS as - ref
    ADCON1bits.ADPREF = 3; //choose FVR as + reference
    ADCON1bits.ADCS = 0;   //select Fosc/2 as conversion clock source
    ADCON1bits.ADFM = 0; //left justify the result
    ADCON0bits.ADON = 1; //turn on ADC
#endif
    
    
    
    ADC_INT_EN = 1;
    
}

void init_UART() {

#ifdef PIC16F1847
    unsigned int baudrate1 = 50;  
    unsigned int baudrate2 = 50;

    //configure UART1 (used for zigbee)
    UART1_RX_PIN_TRIS = 1; //set rx pin as input
    UART1_TX_PIN_TRIS = 0; //set tx pin as output
    APFCON1bits.TXCKSEL = 0; //set TX to pin RB2
    APFCON0bits.RXDTSEL = 0; //set RX to pin RB1

    RCSTAbits.SPEN = 1; //enable receiver
    TXSTAbits.TXEN = 1; //enable transmitter
    TXSTAbits.SYNC = 0;
    TXSTAbits.BRGH = 1;  //high speed baud rate generator
    TXSTAbits.TRMT = 1;
    BAUDCONbits.BRG16 = 0;
    SPBRGH = (baudrate1 & 0xff00) >>  8;
    SPBRGL = baudrate1 & (0x00ff);    //baud rate of 19200...hopefully

    PIE1bits.RCIE = 1;
    RCSTAbits.CREN = 1;
    
#endif
    
#ifdef PIC18F46J50
    unsigned int baudrate1 = 104;  
    unsigned int baudrate2 = 104;

    //configure UART1 (used for zigbee)
    UART1_RX_PIN_TRIS = 1; //set rx pin as input
    UART1_TX_PIN_TRIS = 0; //set tx pin as output
    
    RCSTA1bits.SPEN = 1; //enable receiver
    TXSTA1bits.TXEN = 1; //enable transmitter
    
    TXSTA1bits.SYNC = 0;
    TXSTA1bits.BRGH = 1;  //high speed baud rate generator
    RCSTA1bits.CREN = 1;
    TXSTA1bits.TRMT = 1;
    BAUDCON1bits.BRG16 = 1;
    
    SPBRGH1 = (baudrate1 & 0xFF00) >> 8; //baudrate of 115200
    SPBRG1 = (baudrate1 & 0x00FF);

    UART1_RX_INT_ENABLE = 1;
    
    //configure UART2 (used for rasberry pi)
    UART2_TX_PIN_TRIS = 0;
    UART2_TX_PIN_TRIS = 0;
    
    RPOR1 = 5; //map RP1 (RA1) to UART2 tx
    RPINR16 = 2; //map RX2 to RP2 (RA5)
            
    //config the output pins
    RCSTA2bits.SPEN = 1; //enable receiver
    TXSTA2bits.TXEN = 1; //enable transmitter

    TXSTA2bits.SYNC = 0;
    TXSTA2bits.BRGH = 1;  //high speed baud rate generator
    RCSTA2bits.CREN = 1;
    TXSTA2bits.TRMT = 1;
    BAUDCON2bits.BRG16 = 1;

    SPBRGH2 = (baudrate2 & 0xFF00) >> 8; //baudrate of 115200
    SPBRG2 = (baudrate2 & 0x00FF);
    
    UART2_RX_INT_ENABLE = 1;
#endif
    
}

void init_SPI() {
    
}


void init_timers() {
    //use one timer as a master system timer that will trigger an interrupt
    //on every one millisecond 'tick'. This is an easy way for many different 
    //peripherals to make use of a 'low speed' timer instead of configuring 
    //many different timers
    
#ifdef PIC16F1847   
    //setup timer 1 for 1MHz operation trigger an interrupt every 1000 timer ticks
    //for 1ms system tick
    T1CONbits.TMR1CS = 0; //use Fosc/4 = 4MHz
    T1CONbits.T1CKPS = 2; //1:4 prescalar = 1MHz
    T1CONbits.TMR1ON = 1; //enable timer 1
    
    CCP1CONbits.CCP1M = 10; //set compare mode and software interrupt mode
    CCPR1H = (1000 >> 8) & 0x00FF;
    CCPR1L = (1000 & 0x00FF);
    
    CCP1IE = 1; //enable CCP interrupt
#endif
    
#ifdef PIC18F46J50
    //setup timer 1 for 
    //for 1ms system tick
    T1CONbits.TMR1CS = 3; //use LFINTOSC = 32kHz
    T1CONbits.T1CKPS = 0; //1:1 prescalar = 32kHz
    T1CONbits.TMR1ON = 1; //enable timer 1
    
    CCP1CONbits.CCP1M = 10; //set compare mode and software interrupt mode
    CCPR1H = (32 >> 8) & 0x00FF; //32 ticks in a ms
    CCPR1L = (32 & 0x00FF);
    
    CCP1IE = 1; //enable CCP interrupt
    
    //set up CCP CCP1 gets timer 1 CCP2 gets timer 3
    TCLKCON = 1;
    
    //setup timer 0 for 
    //for 100uS RF timer
    T3CONbits.TMR3CS = 0;  //use FOSC / 4 = 12MHz
    T3CONbits.T3CKPS = 2;  //1:4 prescalar = 3MHz or 1/3uS
    T3CONbits.TMR3ON = 1; //enable timer 3
    
    CCP2CONbits.CCP2M = 10; //set compare mode and software interrupt mode
    CCPR2H = (300 >> 8) & 0x00FF; //interrupt every 100uS
    CCPR2L = (300 & 0x00FF);
    
    CCP2IE = 0; //disable CCP interrupt for now    
    
    
    
#endif
}


//FUNCTIONS TO IMPLEMENT CIRCULAR BUFFER
int BUFF_push(BUFFER *buff, char c) {
  if((buff->tail + 1) % MAX_BUFFSIZE == buff->head) {
    return BUFF_FULL;
  } else {
    buff->data[buff->tail] = c;
    buff->tail = (buff->tail + 1) % MAX_BUFFSIZE;
  }
  return BUFF_NORMAL;
}

char BUFF_pop(BUFFER *buff) {
  char c = -1;
  if(buff->head == buff->tail) {
    return BUFF_EMPTY;
  } else {
    c = buff->data[buff->head];
    buff->head = (buff->head + 1) % MAX_BUFFSIZE;
  }
  return c;
}

int BUFF_status(BUFFER *buff) {
  if(buff->head == buff->tail) {
    return BUFF_EMPTY;
  } else if ((buff->tail + 1) % MAX_BUFFSIZE == buff->head) {
    return BUFF_FULL;
  } else {
    return BUFF_NORMAL;
  }
}