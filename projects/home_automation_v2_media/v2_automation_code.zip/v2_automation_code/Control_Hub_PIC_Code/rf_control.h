/* 
 * File:   rf_control.h
 * Author: Scott
 *
 * Created on November 4, 2015, 8:33 PM
 */

#ifndef RF_CONTROL_H
#define	RF_CONTROL_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif


typedef struct _rf_signal {
    //each number in the array represents the amount of time the signal should stay
    //high or low before toggling. All signals start in the LOW position and
    //toggle to HIGH after code[0] * 100 microseconds (1 'code' unit is 100 uS)
    unsigned int code[64]; 
    unsigned int length; // length of the signal
} rf_signal;


//wraps any rf signal that uses the shot-long pulse modulation where a '1' is
//a long pulse high followed by a short duration low and a '0' is a short pulse
//high followed by a long pulse low. 
typedef struct _short_long_modultation_signal_t {
    rf_signal signal;
    unsigned int data;
    unsigned int period;
    unsigned int short_duration;
    unsigned int long_duration;
} short_long_modulation_signal_t;



//make nice structs to call  for each application of low level RF signals
typedef struct _woods_outlets {
    short_long_modulation_signal_t on_1;
    short_long_modulation_signal_t off_1;
    short_long_modulation_signal_t on_2;
    short_long_modulation_signal_t off_2;
    short_long_modulation_signal_t on_3;
    short_long_modulation_signal_t off_3;
} woods_outlets_t;


//-------------------------SIGNAL DEFINITIONS----------------------

//WOODS REMOTE OUTLETS - short/long encoding 0 is short 1 is long
#define WOODS_ON_1 0x2116   //0010 0001 0001 0110
#define WOODS_OFF_1 0x2216  //0010 0010 0001 0110
#define WOODS_ON_2 0x2416   //0010 0100 0001 0110
#define WOODS_OFF_2 0x2816  //0010 1000 0001 0110
#define WOODS_ON_3 0x2096   //0010 0000 1001 0110
#define WOODS_OFF_3 0x2056  //0010 0000 0101 0110


//variables
woods_outlets_t woods_outlets;
rf_signal *current_signal;
unsigned int rf_current_idx;
char rf_signal_in_progress;
unsigned char rf_retry_count;

//functions
void rf_control_init(void);
void populate_short_long_struct(short_long_modulation_signal_t *, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int);
void send_rf_signal(rf_signal *, unsigned char);
void check_and_send_next_rf();
void execute_outlet_light_command(unsigned int, unsigned char);


#endif	/* RF_CONTROL_H */

