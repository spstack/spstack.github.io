/* 
 * File:   setup.h
 * Author: Scott
 *
 * Created on August 21, 2015, 11:52 AM
 */

#ifndef SETUP_H
#define	SETUP_H

#ifdef	__cplusplus
extern "C" {
#endif
#ifdef	__cplusplus
}
#endif


//circular buffer functions
int BUFF_push(BUFFER*, char);
char BUFF_pop(BUFFER*);
int BUFF_status(BUFFER*);

void initial_setup();
void init_GPIO();
void init_timers();
void init_UART();
void init_SPI();
void init_adc();
void init_system_variables();
void configure_oscillator();



#endif	/* SETUP_H */

