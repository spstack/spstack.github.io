/* 
 * File:   main.c
 * Author: Scott
 *
 * Created on August 21, 2015, 11:36 AM
 */
#include <xc.h>
//#include <stdio.h>
//#include <stdlib.h>

#include "main.h"
#include "bluetooth.h"
#include "pi.h"
#include "setup.h"
#include "temp_sensor.h"
#include "zigbee.h"
#include "interrupts.h"
#include "peripherals.h"
#include "rf_control.h"


char debug_message_to_send[] = "hello!";
unsigned int cntr = 0;
unsigned int i;
int current_temperature;
char *zigbee_addr;
host_data_t *cur_host_packet;



int main(int argc, char** argv) {
    //setup all hardware
    initial_setup();
    enable_interrupts();
    
    zigbee_addr = ZIGBEE_DEVICE1_ADDR;
    
    for (i=0; i <= 5; i++) {
        set_debug_led_on();
        timer_wait_ms(100);
        set_debug_led_off();
        timer_wait_ms(100);
    }

    //MAIN LOOP - check for status flags set by the interrupt handler and take
    //            appropriate action.
    while(1) {

        //check to see if there's a new character to be transmitted
        UART1_send_next_char();
        UART2_send_next_char();
     
        
        //--------------------------------------------------------------------
        //                      ZIGBEE RX DATA
        //--------------------------------------------------------------------
        //check zigbee receive status and take action if complete
        if (zigbee_rx_byte_and_parse() == ZIGBEE_FRAME_COMPLETE) {
            zigbee_copy_frame(&zigbee_temp_rx_frame, &zigbee_cur_frame);
            
            //if the received data packet is a intended for the host pc to handle
            //forward the packet onto the host computer
            
            if (is_host_packet((char *)&zigbee_cur_frame.data)) {
                cur_host_packet = (host_data_t *)&zigbee_cur_frame.data;
                
                //if packet is destined for this baseboard, take action otherwise,
                //forward on to the host PC for handling
                if (cur_host_packet->dst_id == SOURCE_ID_CONTROL_BASEBOARD) {
                    host_pc_handle_incoming_packet(cur_host_packet);
                    host_pc_send_packet(cur_host_packet);
                } else {
                    host_pc_send_packet(cur_host_packet);
                }
                
            }
            else if (zigbee_cur_frame.data[0] == 'h') {
                for (i=0; i <= 5; i++) {
                    set_debug_led_on();
                    timer_wait_ms(100);
                    set_debug_led_off();
                }
            }
        }

        //--------------------------------------------------------------------
        //                      HOST PC RX DATA
        //--------------------------------------------------------------------
        //check host PC rx data to see if anything needs to be sent out or handled
        if (host_pc_rx_byte_and_parse() == HOST_PC_FRAME_COMPLETE) {
            if (temp_rx_host_packet.dst_id == SOURCE_ID_CONTROL_BASEBOARD) {
                host_pc_handle_incoming_packet(&temp_rx_host_packet);
            } else {
                zigbee_forward_host_packet((char *)&temp_rx_host_packet);
            }
        }
        
        
        
        //--------------------------------------------------------------------
        //                       TEMPERATURE DATA
        //--------------------------------------------------------------------       
        //if temperature timer has expired, take temperature and stage for output over I2C.
        if (TEMPERATURE_TIMER >= 60000) {
            TEMPERATURE_MINUTE_TIMER += 1;
            TEMPERATURE_TIMER = 0;
        }
        //take temperature every 10 minutes
        if (TEMPERATURE_MINUTE_TIMER >= 15) {
            DEBUG_LED = 1;
            timer_wait_ms(200);
            DEBUG_LED = 0;
            start_temperature_conversion();
            TEMPERATURE_MINUTE_TIMER = 0;
        }
        
        if (TEMPERATURE_CONVERSION_DONE_FLAG) {
            TEMPERATURE_CONVERSION_DONE_FLAG = 0;
            current_temperature = get_temperature_conversion();
            host_pc_send_temperature_packet(current_temperature, SOURCE_ID_CONTROL_BASEBOARD);     
        }
        
        //--------------------------------------------------------------------
        //                       RF HANDLING
        //--------------------------------------------------------------------
        check_and_send_next_rf();
        
       
        


    }
    return (-1); //never get here
}



