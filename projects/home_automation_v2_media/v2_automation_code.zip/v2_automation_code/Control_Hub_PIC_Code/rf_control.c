#include <xc.h>

#include "main.h"
#include "rf_control.h"
#include "pi.h"
#include "peripherals.h"


void rf_control_init(void) {
    //populate all raw rf signals with data
    
    //init woods outlet control
    populate_short_long_struct(&woods_outlets.off_1, 24, 6, 18, WOODS_OFF_1, 16);
    //woods_outlets.off_1.signal.code[0] = 100; //start sequence
    populate_short_long_struct(&woods_outlets.on_1, 24, 6, 18, WOODS_ON_1, 16);
    //woods_outlets.on_1.signal.code[0] = 100; //start sequence
    populate_short_long_struct(&woods_outlets.off_2, 24, 6, 18, WOODS_OFF_2, 16);
    ///woods_outlets.off_2.signal.code[0] = 100; //start sequence
    populate_short_long_struct(&woods_outlets.on_2, 24, 6, 18, WOODS_ON_2, 16);
    ///woods_outlets.on_2.signal.code[0] = 100; //start sequence
    populate_short_long_struct(&woods_outlets.off_3, 24, 6, 18, WOODS_OFF_3, 16);
    //woods_outlets.off_3.signal.code[0] = 100; //start sequence
    populate_short_long_struct(&woods_outlets.on_3, 24, 6, 18, WOODS_ON_3, 16);
    //woods_outlets.on_3.signal.code[0] = 100; //start sequence
    
    RF_TIMER_INT_EN = 0;
    
}

void populate_short_long_struct(short_long_modulation_signal_t *sl_struct, unsigned int period, unsigned int short_duration, unsigned int long_duration, unsigned int data, unsigned int length) {
    unsigned int i;
    
    sl_struct->period = period-1;
    sl_struct->short_duration = short_duration;
    sl_struct->long_duration = long_duration;
    sl_struct->signal.length = length*2;
    
    //create the rf signal that dictates how long each pulse is high/low
    for (i=0; i<length; i++) {
        if ((data >> i) % 2 == 1) {
            sl_struct->signal.code[i*2] = sl_struct->long_duration;
        } else {
            sl_struct->signal.code[i*2] = sl_struct->short_duration;
        }
        
        sl_struct->signal.code[i*2+1] = sl_struct->period - sl_struct->signal.code[i*2];
    }
}

void send_rf_signal(rf_signal *rf, unsigned char num_times) {
    current_signal = rf;
    rf_signal_in_progress = 1;
    rf_retry_count = num_times;
    rf_current_idx = 0;
    
    //start rf timer
    RF_TIMER_INT_EN = 1;
    RF_TIMER = 0;
    RF_PIN = 1;
    TMR3H = 0;
    TMR3L = 0;
}


void check_and_send_next_rf() {
    if (rf_signal_in_progress == 0) {
        return;
    }
    
    
    //if done, be done
    if (rf_current_idx >= current_signal->length - 1) {
        RF_PIN = 0;                        
        
        if (rf_retry_count == 0) {
            rf_signal_in_progress = 0;
            RF_TIMER_INT_EN = 0;
        } else {
            rf_retry_count -= 1;
            timer_wait_ms(13);
            send_rf_signal(current_signal, rf_retry_count);
            
        }
    }
    
    //if time to change output, do it
    else if (RF_TIMER >= current_signal->code[rf_current_idx]) {
        RF_PIN ^= 1;
        rf_current_idx++;
        RF_TIMER = 0;
    }
    
    
    
    
}

//start sequence needed to get woods outlets working
void send_woods_start_seq() {
    RF_PIN = 1;
    timer_wait_ms(10);
}


void execute_outlet_light_command(unsigned int outlet_light_id, unsigned char brightness) {
    
    switch(outlet_light_id) {
        case OUTLET_LIGHT_ID_WOODS_1:
            send_woods_start_seq();
            if (brightness < 50) {
                send_rf_signal(&woods_outlets.off_1.signal, 10);
            } else {
                send_rf_signal(&woods_outlets.on_1.signal, 10);
            }
            break;
            
        case OUTLET_LIGHT_ID_WOODS_2:
            send_woods_start_seq();
            if (brightness < 50) {
                send_rf_signal(&woods_outlets.off_2.signal, 10);
            } else {
                send_rf_signal(&woods_outlets.on_2.signal, 10);
            }
            break;
         
        case OUTLET_LIGHT_ID_WOODS_3:
            send_woods_start_seq();
            if (brightness == 0) {
                send_rf_signal(&woods_outlets.off_3.signal, 10);
            } else {
                send_rf_signal(&woods_outlets.on_3.signal, 10);
            }
            break;
            
        default:
            break;
    }
}
