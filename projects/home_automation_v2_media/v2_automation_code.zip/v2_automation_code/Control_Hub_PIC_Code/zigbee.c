#include <xc.h>
#include "main.h"
#include "zigbee.h"
#include "peripherals.h"
#include "pi.h"

void init_zigbee() {
    frame_id = 1;
    zigbee_cur_rx_frame_idx = 0;
    zigbee_cur_rx_frame_length = 0;
    zigbee_cur_rx_frame_data_idx = 0;
    
    //Declare source id mappings
    ZIGBEE_SOURCE_ID_ADDR_MAPPING[0] = ZIGBEE_COORDINATOR_ADDR_ZEROS;
    ZIGBEE_SOURCE_ID_ADDR_MAPPING[SOURCE_ID_CONTROL_BASEBOARD] = ZIGBEE_COORDINATOR_ADDR;
    ZIGBEE_SOURCE_ID_ADDR_MAPPING[SOURCE_ID_DEVICE1] = ZIGBEE_DEVICE1_ADDR;
    ZIGBEE_SOURCE_ID_ADDR_MAPPING[SOURCE_ID_DEVICE2] = ZIGBEE_DEVICE2_ADDR;
    ZIGBEE_SOURCE_ID_ADDR_MAPPING[SOURCE_ID_DEVICE3] = ZIGBEE_DEVICE3_ADDR;
    
};
    


void zigbee_send_message(char macaddr[], char *data, int length) {
    unsigned int i, msg_length = 0;
    unsigned int checksum = 0;
    char send_buffer[MAX_BUFFSIZE + 19];

    /*format of a message is:
     * 0x7E   : start of frame
     * 0x---- : 2 bytes length of message (all bytes after length not including checksum
     * 0x--   : cmd identifier
     * 0x--   : frame id
     * 0x---------------- : 64bit destination address
     * NOT USED 0x---- : 16 bit destination address (set to 0xFFFE if using 64 bit)
     * NOT USED 0x--   : broadcast radius (0x00)
     * 0x--   : Options (0x00)
     * 0x<>   : Actual data message to be transmitted
     * 0x--   : one byte checksum (0xFF minus sum of all data bytes between length and checksum byte)
     * 
     */

    msg_length = length + 14;

    //construct the API frame to send some data!
    send_buffer[0] = ZIGBEE_SOF;
    send_buffer[1] = (msg_length & 0xff00) >> 8;  //next 2 bytes are length of the message
    send_buffer[2] = (msg_length & 0x00ff);
    send_buffer[3] = ZIGBEE_TX_REQUEST_TYPE;
    send_buffer[4] = frame_id;
    frame_id += 1;
    if (frame_id == 0) {
        frame_id = 1;
    }

    //64 bit adress field
    for (i=0; i<8; i++) {
        send_buffer[i+5] = macaddr[i]; //(macaddr >> (56 - (8*i))) & 0xFF;
    }

    send_buffer[13] = 0xff;
    send_buffer[14] = 0xfe;
    send_buffer[15] = 0x00;   //broadcast radius
    send_buffer[16] = 0x00;  //options field

    for (i=0; i<length; i++) {
        send_buffer[i+17] = data[i];
    }
    
    //calculate checksum...
    checksum = 0;
    for (i=3; i<msg_length+3; i++) {
        checksum += send_buffer[i];
    }
    checksum = checksum & 0xff;
    checksum = 0xff - checksum;
    send_buffer[i] = (char)checksum;

    UART1_send_data(send_buffer, msg_length+4);
    
}


//pop the next byte off of the UART Rx stack and build into frame
//if rx byte is the last one in the frame return ZIGBEE_FRAME_COMPLETE
int zigbee_rx_byte_and_parse() {
    char next_byte;

    if (UART1_rx_status() != BUFF_EMPTY) {
        set_debug_led_on();
        next_byte = UART1_rx_next_byte();
    } else {
        set_debug_led_off();
        return ZIGBEE_FRAME_INCOMPLETE;
    }

    switch (zigbee_cur_rx_frame_idx) {
        case 0:
            if (next_byte == ZIGBEE_SOF) {
                zigbee_temp_rx_frame.SOF = next_byte;
                zigbee_cur_rx_frame_idx = 1;
            } else {
                zigbee_cur_rx_frame_idx = 0;
            }
            break;


        case 1:
            zigbee_temp_rx_frame.length_u = next_byte;
            zigbee_cur_rx_frame_idx += 1;
            break;

        case 2:
            zigbee_temp_rx_frame.length_l = next_byte;
            zigbee_cur_rx_frame_length = zigbee_temp_rx_frame.length_u;
            zigbee_cur_rx_frame_length = ((zigbee_cur_rx_frame_length << 8) & 0xFF00) + (zigbee_temp_rx_frame.length_l & 0x00FF);
            zigbee_cur_rx_frame_idx += 1;
            break;

        case 3:
            if (next_byte == ZIGBEE_RX_PACKET_TYPE ) {
                zigbee_temp_rx_frame.packet_type = next_byte;
                zigbee_cur_rx_frame_idx += 1;
            } else {
                zigbee_cur_rx_frame_idx = 0;
            }
            break;

        //64 bit address section
        case 4:
            zigbee_temp_rx_frame.address_64[0] = next_byte;
            zigbee_cur_rx_frame_idx += 1;
            break;
        case 5:
            zigbee_temp_rx_frame.address_64[1] = next_byte;
            zigbee_cur_rx_frame_idx += 1;
            break;
        case 6:
            zigbee_temp_rx_frame.address_64[2] = next_byte;
            zigbee_cur_rx_frame_idx += 1;
            break;
        case 7:
            zigbee_temp_rx_frame.address_64[3] = next_byte;
            zigbee_cur_rx_frame_idx += 1;
            break;
        case 8:
            zigbee_temp_rx_frame.address_64[4] = next_byte;
            zigbee_cur_rx_frame_idx += 1;
            break;
        case 9:
            zigbee_temp_rx_frame.address_64[5] = next_byte;
            zigbee_cur_rx_frame_idx += 1;
            break;
        case 10:
            zigbee_temp_rx_frame.address_64[6] = next_byte;
            zigbee_cur_rx_frame_idx += 1;
            break;
        case 11:
            zigbee_temp_rx_frame.address_64[7] = next_byte;
            zigbee_cur_rx_frame_idx += 1;
            break;

        //16 bit address section
        case 12:
            zigbee_temp_rx_frame.address_16[0] = next_byte;
            zigbee_cur_rx_frame_idx += 1;
            break;
        case 13:
            zigbee_temp_rx_frame.address_16[1] = next_byte;
            zigbee_cur_rx_frame_idx += 1;
            break;

        case 14:
            zigbee_temp_rx_frame.rx_options = next_byte;
            zigbee_cur_rx_frame_idx += 1;
            break;

        default:
            if (zigbee_cur_rx_frame_idx < (zigbee_cur_rx_frame_length + 3)) {
                zigbee_temp_rx_frame.data[zigbee_cur_rx_frame_data_idx] = next_byte;
                zigbee_cur_rx_frame_idx += 1;
                zigbee_cur_rx_frame_data_idx += 1;
            }
            else if (zigbee_cur_rx_frame_idx == (zigbee_cur_rx_frame_length + 3)) {
                zigbee_temp_rx_frame.checksum = next_byte;
                zigbee_cur_rx_frame_idx = 0;
                zigbee_cur_rx_frame_data_idx = 0;
                return ZIGBEE_FRAME_COMPLETE;
            }
            else {
                //frame overrun somehow...
                zigbee_cur_rx_frame_idx = 0;
                zigbee_cur_rx_frame_length = 0;
                zigbee_cur_rx_frame_data_idx = 0;
            }
    }

    return ZIGBEE_FRAME_INCOMPLETE;

    
}

void zigbee_copy_frame(zigbee_rx_frame_t *src, zigbee_rx_frame_t *dst) {
    unsigned int data_length;

    dst->SOF = src->SOF;
    dst->length_u = src->length_u;
    dst->length_l = src->length_l;
    data_length = dst->length_u;
    data_length = (data_length << 8) | dst->length_l;
    data_length = data_length - 12; //data length is packet length - non-data
    dst->packet_type = src->packet_type;
    deep_copy(src->address_64, &dst->address_64, 8);
    dst->address_16[0] = src->address_16[0];
    dst->address_16[1] = src->address_16[1];
    dst->rx_options = src->rx_options;
    deep_copy(src->data, dst->data, data_length);
    dst->checksum = src->checksum;
}


void zigbee_forward_host_packet(char *packet) {
    unsigned int datalength;
    host_data_t *h_packet;
    
    h_packet = (host_data_t *)packet;
    
    datalength = (h_packet->data_length_H << 8) | h_packet->data_length_L;
    if (h_packet->dst_id < MAX_ZIGBEE_ADDRESSES) {
        zigbee_send_message(ZIGBEE_SOURCE_ID_ADDR_MAPPING[h_packet->dst_id], (char *)packet, 6 + datalength);
    }
}