#include <xc.h>
#include "peripherals.h"
#include "main.h"
#include "pi.h"
#include "rf_control.h"


/* The communication with the host PC (RPi) is planned to be done over UART. It's the
 * only protocol the allows both sides to initiale data transfer at will.
 * The problem with this is that there are only 2 UART ports and bluetooth/rpi/
 * and xbee all require UART.
 * 
 */


void init_pi() {
    hostpc_cur_rx_idx = 0;
    hostpc_cur_rx_data_idx = 0;
    hostpc_cur_rx_datalength = 0;
}


void host_pc_send_raw_data(char *data, int length) {
    set_uart2_source_sel(UART2_HOST_PC);
    UART2_send_data(data, length);
}


//send a completed data packet to the host
void host_pc_send_packet(host_data_t *packet) {
    unsigned int datalength;
    
    set_uart2_source_sel(UART2_HOST_PC);
    UART2_send_char(packet->start_byte);
    UART2_send_char(packet->packet_type);
    UART2_send_char(packet->data_length_H);
    UART2_send_char(packet->data_length_L);
    datalength = (packet->data_length_H << 8) | packet->data_length_L;
    UART2_send_char(packet->source_id);
    UART2_send_char(packet->dst_id);
    UART2_send_data(packet->payload_data.data, datalength);
}


//send a temperature data packet
void host_pc_send_temperature_packet(int temperature, unsigned char source_id) {
    temp_host_packet.start_byte = 0xAA;
    temp_host_packet.packet_type = TEMPERATURE_PACKET_TYPE;
    temp_host_packet.data_length_H = 0;
    temp_host_packet.data_length_L = 3;
    temp_host_packet.source_id = source_id;
    temp_host_packet.dst_id = 1; // baseboard destination
    temp_host_packet.payload_data.temperature_data.temperature_H = (char)((temperature >> 8) & 0x00FF);
    temp_host_packet.payload_data.temperature_data.temperature_L = (char)(temperature & 0x00FF); 
    
    host_pc_send_packet(&temp_host_packet);
}

void host_pc_send_humidity_packet(unsigned char humidity, unsigned char source_id) {
    temp_host_packet.start_byte = 0xAA;
    temp_host_packet.packet_type = HUMIDITY_PACKET_TYPE;
    temp_host_packet.data_length_H = 0;
    temp_host_packet.data_length_L = 3;
    temp_host_packet.source_id = source_id;
    temp_host_packet.dst_id = 1; // baseboard destination
    temp_host_packet.payload_data.humidity_data.relative_humidity = humidity;
    
    host_pc_send_packet(&temp_host_packet);
}


//if the buffer is valid host data packet return packet type else return false (0)
char is_host_packet(char *data) {
    if (data[0] == 0xAA) {
        return data[1];
    }
    else {
        return 0;
    }
}

char host_pc_rx_byte_and_parse() {
    char next_byte;
    
    if (UART2_rx_status() != BUFF_EMPTY) {
        set_debug_led_on();
        next_byte = UART2_rx_next_byte();
    } else {
        set_debug_led_off();
        return HOST_PC_FRAME_INCOMPLETE;
    }
    
    
    switch(hostpc_cur_rx_idx) {
        case 0:
            if (next_byte == 0xaa){
                hostpc_cur_rx_idx += 1;
                temp_rx_host_packet.start_byte = next_byte;
                break;
            } else {
                hostpc_cur_rx_idx = 0;
                break;
            }
        case 1:
            temp_rx_host_packet.packet_type = next_byte;
            hostpc_cur_rx_idx += 1;
            break;
        case 2:
            temp_rx_host_packet.data_length_H = next_byte;
            hostpc_cur_rx_idx += 1;
            break;
        case 3:
            temp_rx_host_packet.data_length_L = next_byte;
            hostpc_cur_rx_idx += 1;
            hostpc_cur_rx_data_idx = 0;
            hostpc_cur_rx_datalength = (temp_rx_host_packet.data_length_H << 8) | (temp_rx_host_packet.data_length_L);
            break;
            
        case 4:
            temp_rx_host_packet.source_id = next_byte;
            hostpc_cur_rx_idx += 1;
            break;
        case 5:
            temp_rx_host_packet.dst_id = next_byte;
            hostpc_cur_rx_idx += 1;
            break;
            
        default:
            if (hostpc_cur_rx_data_idx <= hostpc_cur_rx_datalength) {
                temp_rx_host_packet.payload_data.data[hostpc_cur_rx_data_idx] = next_byte;
                hostpc_cur_rx_data_idx += 1;
                if (hostpc_cur_rx_data_idx == hostpc_cur_rx_datalength) {
                    hostpc_cur_rx_idx = 0;
                    hostpc_cur_rx_data_idx = 0;
                    hostpc_cur_rx_datalength = 0;
                    return HOST_PC_FRAME_COMPLETE;
                }
            } else { //something went wrong... start over
                hostpc_cur_rx_idx = 0;
                hostpc_cur_rx_data_idx = 0;
                hostpc_cur_rx_datalength = 0;
                return HOST_PC_FRAME_INCOMPLETE;
            }
            break;
    }
    
    return HOST_PC_FRAME_INCOMPLETE;
    
}


void host_pc_handle_incoming_packet(host_data_t *packet) {
    
    if (packet->packet_type == OUTLET_LIGHT_CONTROL_PACKET_TYPE) {
        //if outlet/light is an RF device handle request in the rf 
        if (packet->payload_data.outlet_light_control_data.outlet_light_id >= OUTLET_LIGHT_ID_RF_MIN && packet->payload_data.outlet_light_control_data.outlet_light_id <= OUTLET_LIGHT_ID_RF_MAX) {
            execute_outlet_light_command(packet->payload_data.outlet_light_control_data.outlet_light_id, packet->payload_data.outlet_light_control_data.brightness);        
        }
    }
}