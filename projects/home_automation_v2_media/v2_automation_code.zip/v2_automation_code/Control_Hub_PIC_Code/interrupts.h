/* 
 * File:   interrupts.h
 * Author: Scott
 *
 * Created on August 21, 2015, 11:40 AM
 */

#ifndef INTERRUPTS_H
#define	INTERRUPTS_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif


void interrupt isr(void);
void init_interrupts();
void enable_interrupts();
void disable_interrupts();

#endif	/* INTERRUPTS_H */

