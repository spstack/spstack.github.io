/* 
 * File:   pi.h
 * Author: Scott
 *
 * Created on August 21, 2015, 11:56 AM
 */

#ifndef PI_H
#define	PI_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

// ------------packet type declarations----------------
#define TEMPERATURE_PACKET_TYPE 1
#define HUMIDITY_PACKET_TYPE 2
#define LIGHT_STATUS_PACKET_TYPE 3
#define THERMOSTAT_STATUS_PACKET_TYPE 4
#define POWER_USAGE_PACKET_TYPE 5
#define LOCK_STATUS_PACKET_TYPE 6
#define OUTLET_LIGHT_CONTROL_PACKET_TYPE 7


//packet source_id declarations. Change the name of these if a module moves around
#define SOURCE_ID_CONTROL_BASEBOARD 1  //source is the main host control unit (this program)
#define SOURCE_ID_DEVICE1 2 //source is the test sensor module currently in bedroom 
#define SOURCE_ID_DEVICE2 3 //source is the test sensor module currently in living room 
#define SOURCE_ID_DEVICE3 4 //source is the test sensor module currently in ____ 

#define OUTLET_LIGHT_ID_RF_MIN 1
#define OUTLET_LIGHT_ID_RF_MAX 20
#define OUTLET_LIGHT_ID_WOODS_1 1
#define OUTLET_LIGHT_ID_WOODS_2 2
#define OUTLET_LIGHT_ID_WOODS_3 3


#define HOST_PC_FRAME_COMPLETE 1
#define HOST_PC_FRAME_INCOMPLETE 0



/* data packet definition for sending data to the host pc
 * 
 *  start byte       - 0xaa
 *  packet type byte - temperature/humidity/etc...
 *  data_length byte - length of the payload data to be sent (varies depending on packet type
 *  payload          - actual data
 * 
 */ 
typedef struct _host_data_t {
    char start_byte;   //0xaa
    unsigned char packet_type;  
    char data_length_H; //length of actual data
    char data_length_L;
    unsigned char source_id; //source of the packet
    unsigned char dst_id;   //destination (if applicable) for packet
    union _payload_data {
        char data[MAX_BUFFSIZE]; //access the data as raw byte array
        
        //temperature packet (type 0x01)
        //data is just 3 bytes 2 for signed temperature value in deg C and 1 for
        //the source of the temperature data.
        struct _temperature_data {
            char temperature_H;
            char temperature_L;
        } temperature_data;
        
        
        //humidity packet (type 0x2)
        //data is just 2 bytes 1 for relative humidity in % and 1 for source of
        //the humidity data
        struct _humidity_data {
            unsigned char relative_humidity;
        } humidity_data;
        
        
        struct _outlet_light_control_data {
            unsigned int outlet_light_id;
            unsigned char brightness; //value from 0-100 even if light doesn't dim use to turn on/off
        } outlet_light_control_data;
            
        
    } payload_data;
    
} host_data_t;
    




//functions
void init_pi();
void host_pc_send_raw_data(char *, int);
void host_pc_send_packet(host_data_t *);
void host_pc_send_temperature_packet(int, unsigned char);
void host_pc_send_humidity_packet(unsigned char humidity, unsigned char source_id);
char is_host_packet(char *);
char host_pc_rx_byte_and_parse();
void host_pc_handle_incoming_packet(host_data_t *);




//variables
host_data_t temp_host_packet;
host_data_t temp_rx_host_packet;
unsigned int hostpc_cur_rx_idx;
unsigned int hostpc_cur_rx_data_idx;
unsigned int hostpc_cur_rx_datalength;

#endif	/* PI_H */

