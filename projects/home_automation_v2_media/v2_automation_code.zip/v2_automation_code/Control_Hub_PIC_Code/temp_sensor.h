/* 
 * File:   temp_sensor.h
 * Author: Scott
 *
 * Created on August 21, 2015, 12:17 PM
 */

#ifndef TEMP_SENSOR_H
#define	TEMP_SENSOR_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

void init_tempSensor();
void start_temperature_conversion();
int get_temperature_conversion();

#endif	/* TEMP_SENSOR_H */

