#include <xc.h>
#include "temp_sensor.h"
#include "main.h"


void init_tempSensor() {
    
}


//since conversion might take a little while, start the conversion then use 
//interrupt to actually get the converted value
void start_temperature_conversion() {
    TEMP_SENSOR_INITIATE_CONVERSION_BIT = 1;  //initiate the ADC then quit
}

//return temperature in scaled 14bit ADC value
int get_temperature_conversion() {
    signed long temp;
    int temperature;
    
    temp = ADC_CONVERSION_REG_H;
    temp = (temp << 2);
    
#ifdef PIC16F1847   
    //conversion rate is 40 'units'per degrees C with the TMP36
    //where 25C is 750mV or 3000 'units'
    ///0 degC is 1000 units or .25V 
    //temperature_C = (temp - 2000) / 40;
#endif
#ifdef PIC18F46J50
    //conversion rate is .01V/1degC
    //1024 steps with 1023 being 3.3V one step ~= .00322V
    //0 deg C is ~.5V and 25C is about .75V
    //.75V is ~240 units -> 240 * 100 / 310 - 50 = 25C
    
    /*  this code is to convert ADC to temperature in degC
    temp = 322 * temp / 100; //get voltage first, then convert voltage to temperature
    temp = (temp * 100) - 50000; 
    temperature_C = temp / 1000;
    */ 
    
    
    //this code is to convert ADC to temperature in scaled 14bit ADC val
    // that the other sensor uses. 0 is -40C and 16381 is 125C
    temperature = (temp - 31) * 16382 / 512;
#endif    

    return temperature;
}