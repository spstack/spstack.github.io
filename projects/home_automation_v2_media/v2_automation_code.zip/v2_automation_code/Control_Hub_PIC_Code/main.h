/* 
 * File:   main.h
 * Author: Scott
 *
 * Created on August 21, 2015, 12:28 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif


#define PIC18F46J50
//#define PIC16F1847


//PIN declarations

//---------------------PIC18F46J50-------------------
#ifdef PIC18F46J50

#define DEBUG_LED LATEbits.LATE0
#define DEBUG_LED_TRIS TRISEbits.TRISE0

#define TX_LED LATAbits.LA0
#define TX_LED_TRIS TRISAbits.TRISA0

#define RX_LED LATAbits.LA3
#define RX_LED_TRIS TRISAbits.TRISA3

#define UART1_TX_PIN_TRIS TRISCbits.TRISC6
#define UART1_RX_PIN_TRIS TRISCbits.TRISC7
#define UART1_RX_INT_ENABLE PIE1bits.RC1IE
#define UART1_RX_INT_FLAG PIR1bits.RC1IF
#define UART1_FRAMING_ERR RCSTA1bits.FERR
#define UART1_OVERRUN_ERR RCSTA1bits.OERR
#define UART1_RX_REG RCREG1
#define UART1_TX_REG TXREG1

#define UART2_TX_PIN_TRIS TRISAbits.TRISA1
#define UART2_RX_PIN_TRIS TRISAbits.TRISA5
#define UART2_RX_INT_ENABLE PIE3bits.RC2IE
#define UART2_RX_INT_FLAG PIR3bits.RC2IF
#define UART2_FRAMING_ERR RCSTA2bits.FERR
#define UART2_OVERRUN_ERR RCSTA2bits.OERR
#define UART2_RX_REG RCREG2
#define UART2_TX_REG TXREG2


#define TEMP_SENSOR_ANSEL ANCON1bits.PCFG9
#define TEMP_SENSOR_PIN_TRIS TRISBbits.TRISB3
#define TEMP_SENSOR_INITIATE_CONVERSION_BIT ADCON0bits.GODONE
#define ADC_CONVERSION_REG_L ADRESL
#define ADC_CONVERSION_REG_H ADRESH
#define ADC_INT_FLAG ADIF
#define ADC_INT_EN ADIE

#define SYSTEM_TIMER_INT_FLAG CCP1IF
#define SYSTEM_TIMER_INT_EN CCP1IE

#define UART_SOURCE_SEL_PIN_TRIS TRISAbits.TRISA3
#define UART_SOURCE_SEL_PIN LATAbits.LATA3

#define RF_PIN LATBbits.LATB5
#define RF_PIN_TRIS TRISBbits.TRISB5
#define RF_TIMER_INT_FLAG PIR2bits.CCP2IF
#define RF_TIMER_INT_EN PIE2bits.CCP2IE

#endif

///---------------------PIC16F1847--------------------
#ifdef PIC16F1847
#define DEBUG_LED LATAbits.LATA1
#define DEBUG_LED_TRIS TRISAbits.TRISA1

#define RX_LED LATAbits.LATA1
#define RX_LED_TRIS TRISAbits.TRISA1

#define UART1_TX_PIN_TRIS TRISBbits.TRISB2
#define UART1_RX_PIN_TRIS TRISBbits.TRISB1
#define UART1_RX_INT_ENABLE PIE1bits.RCIE
#define UART1_RX_INT_FLAG PIR1bits.RCIF
#define UART1_FRAMING_ERR RCSTAbits.FERR
#define UART1_OVERRUN_ERR RCSTAbits.OERR
#define UART1_RX_REG RCREG
#define UART1_TX_REG TXREG
#define UART2_TX_REG TXREG

#define TEMP_SENSOR_ANSEL ANSELAbits.ANSA0
#define TEMP_SENSOR_PIN_TRIS TRISAbits.TRISA0
#define TEMP_SENSOR_INITIATE_CONVERSION_BIT ADCON0bits.ADGO
#define ADC_CONVERSION_REG_L ADRESL
#define ADC_CONVERSION_REG_H ADRESH
#define ADC_INT_FLAG ADIF
#define ADC_INT_EN ADIE

#define SYSTEM_TIMER_INT_FLAG CCP1IF
#define SYSTEM_TIMER_INT_EN CCP1IE

#define UART_SOURCE_SEL_PIN_TRIS TRISAbits.TRISA3
#define UART_SOURCE_SEL_PIN LATAbits.LATA3

#endif



//buffer size declarations
#define MAX_BUFFSIZE 200
#define BUFF_FULL 1
#define BUFF_EMPTY 0xFF
#define BUFF_NORMAL 0


//Buffer used for transmitting and recieving data
typedef struct _BUFFER {
  int head;
  int tail;
  unsigned char data[MAX_BUFFSIZE];
} BUFFER;





//FLAGS - these variables are set usually by interrupt handler
//-       and indicate that something needs attention.

//uart
char UART1_RX_FLAG;
char UART1_TX_FLAG;
char UART2_RX_FLAG;
char UART2_TX_FLAG;

// temperature

char TEMPERATURE_CONVERSION_DONE_FLAG;

//timers
 unsigned int TEMPERATURE_TIMER;
 unsigned int TEMPERATURE_MINUTE_TIMER;
 unsigned int GENERAL_TIMER;
 unsigned int RF_TIMER;


//global variables
BUFFER RX1_BUFF;
BUFFER TX1_BUFF;
BUFFER RX2_BUFF;
BUFFER TX2_BUFF;




unsigned int temperature_timer_ms;





#endif	/* MAIN_H */

