#include <xc.h>
#include "interrupts.h"
#include "main.h"
#include "setup.h"

/*
 The main interrupt handler 
 */

void interrupt isr(void) {
    char temp_char;
    

    if(UART1_RX_INT_ENABLE && UART1_RX_INT_FLAG) {
        //RX_LED ^= 1; //receive LED indicator
        //If framing error...
        if (UART1_FRAMING_ERR == 1) {
            temp_char = UART1_RX_REG;
            RCSTA1bits.SPEN = 0;
            RCSTA1bits.SPEN = 1;
        } else { //put char into receive buffer
            temp_char = UART1_RX_REG;
            BUFF_push(&RX1_BUFF, temp_char);
        }
        UART1_RX_INT_FLAG = 0;
    }
    
    if(UART2_RX_INT_ENABLE && UART2_RX_INT_FLAG) {
        //RX_LED ^= 1; //receive LED indicator
        //If framing error...
        if (UART2_FRAMING_ERR == 1) {
            temp_char = UART2_RX_REG;
            RCSTA2bits.SPEN = 0;
            RCSTA2bits.SPEN = 1;
        } else { //put char into receive buffer
            temp_char = UART2_RX_REG;
            BUFF_push(&RX2_BUFF, temp_char);
        }
        UART2_RX_INT_FLAG = 0;
    }
    
    //interrupt for ADC conversion done
    else if (ADC_INT_FLAG && ADC_INT_EN) {
        TEMPERATURE_CONVERSION_DONE_FLAG = 1;;
        ADC_INT_FLAG = 0;
    }
    
    //interrupt for 1ms system tick
    else if (SYSTEM_TIMER_INT_FLAG && SYSTEM_TIMER_INT_EN) {
        TEMPERATURE_TIMER += 1;
        GENERAL_TIMER += 1;
        
        TMR1H = 0;
        TMR1L = 0;
        SYSTEM_TIMER_INT_FLAG = 0;
    }
    
    else if (RF_TIMER_INT_FLAG && RF_TIMER_INT_EN) {
        RF_TIMER += 1;
        
        TMR3H = 0;
        TMR3L = 0;
        RF_TIMER_INT_FLAG = 0;
    }

    else {

    }



#ifdef PIC18F46J50

#endif
            



}

void init_interrupts() {
    //doesn't do anything right now
    
}

void enable_interrupts() {
    //enable global and peripheral interrupts
    INTCONbits.GIE = 1;
    INTCONbits.PEIE = 1;
}

void disable_interrupts() {
    //enable global and peripheral interrupts
    INTCONbits.GIE = 0;
    INTCONbits.PEIE = 0;
}