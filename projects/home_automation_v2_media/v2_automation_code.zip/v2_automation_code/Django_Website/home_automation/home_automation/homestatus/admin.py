from django.contrib import admin

from .models import temperature
from .models import humidity
from .models import light_status


# Register your models here.
admin.site.register(temperature)
admin.site.register(humidity)
admin.site.register(light_status)
