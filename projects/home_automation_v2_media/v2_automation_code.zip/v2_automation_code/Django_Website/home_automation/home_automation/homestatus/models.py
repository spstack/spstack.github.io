from django.db import models

# Create your models here.


class temperature(models.Model):
    datetime = models.DateTimeField(auto_now=True)
    location = models.CharField(max_length=40)
    temperature = models.IntegerField()
    
    def __str__(self):
        return " Time: %s  |  location: %s   |   temperature: %d" % (str(self.datetime), self.location, self.temperature)

class humidity(models.Model):
    datetime = models.DateTimeField(auto_now=True)
    location = models.CharField(max_length=40)
    humidity = models.PositiveSmallIntegerField()


    def __str__(self):
        return " Time: %s  |  location: %s  |   humidity: %d" % (str(self.datetime), self.location, self.humidity)


class light_status(models.Model):
    last_updated = models.DateTimeField(auto_now=True)
    light_id = models.CharField(max_length=60)
    brightness = models.PositiveSmallIntegerField()


    def __str__(self):
        return " Updated: %s  |  light_id: %s  |  brightness %d" % (str(self.last_updated), self.light_id, self.brightness)



