from django.http import HttpResponse
from django.shortcuts import render
import pytz
from .models import temperature
from .models import humidity
from .models import light_status
from django.utils import timezone

import home_automation.homestatus.baseboard_control.baseboard_ctrl as baseboard_ctrl
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import matplotlib.cbook as cbook
import datetime



baseboard_ctrl_thread = baseboard_ctrl.BaseboardCtrl()
baseboard_ctrl_thread.start()



#----------------------------helper functions ----------------------

mpl_font = { 'family' : 'normal',
             'size'   : 10}

est_timezone = pytz.timezone('America/Los_Angeles')

#generate plot of recent temperature/humidity
def generate_temperature_plot(temperature_location_data, num=24, units='hours'):
    mpl.rc('font', **mpl_font)

    years = mdates.YearLocator()   # every year
    months = mdates.MonthLocator()  # every month
    days = mdates.DayLocator()
    hours = mdates.HourLocator(interval=2)
    dayFmt = mdates.DateFormatter('%m-%d-%Y')  
    hourFmt = mdates.DateFormatter('%H:%M')  


    plt.figure(1)     
    cur_plot = 1
    colors = ['b','r','g','w', 'y']
    t_min = 65
    t_max = 100
    for data in temperature_location_data:
        if len(data) == 0:
            continue
        dts = [d.datetime.astimezone(est_timezone).replace(tzinfo=None) for d in data]   #workaround because mpl doesn't seem to comprehend tz aware datetime
        tmps = [d.temperature for d in data]
        plt.plot(dts, tmps, colors[cur_plot] + 'o-', label=data[0].location)
        cur_plot += 1
        cur_min = min(tmps)
        cur_max = max(tmps)
        if min(tmps) < t_min:
            t_min = cur_min
        if max(tmps) > t_max:
            t_max = cur_max

    plt.legend(loc='best')
    plt.title('House Temperature Over Last %d %s' % (num, units))
    ax = plt.gca()
    ax.xaxis.set_major_locator(days)
    ax.xaxis.set_minor_locator(hours)
    ax.xaxis.set_major_formatter(dayFmt)
    ax.xaxis.set_minor_formatter(hourFmt)
    ax.set_ylim(t_min - 5, t_max + 5)
    plt.xlabel('Datetime')
    plt.ylabel('Temperature (deg F)') 

    frame = plt.gcf()
    frame.autofmt_xdate()
    frame.set_size_inches([6,5])
    frame.savefig('/home/scott/programs/home_automation/home_automation/home_automation/homestatus/static/homestatus/recent_temps.png', dpi=80) 

    plt.clf()
    plt.cla()
    plt.close()


#generate plot of recent humidity/humidity
def generate_humidity_plot(humidity_location_data, num=24, units='hours'):
    mpl.rc('font', **mpl_font)

    years = mdates.YearLocator()   # every year
    months = mdates.MonthLocator()  # every month
    days = mdates.DayLocator()
    hours = mdates.HourLocator(interval=2)
    dayFmt = mdates.DateFormatter('%m-%d-%Y')  
    hourFmt = mdates.DateFormatter('%H:%M')  


    plt.figure(1)     
    cur_plot = 1
    colors = ['g','w','b','r']
    t_min = 65
    t_max = 100
    for data in humidity_location_data:
        if len(data) == 0:
            continue
        dts = [d.datetime.astimezone(est_timezone).replace(tzinfo=None) for d in data]   #workaround because mpl doesn't seem to comprehend tz aware datetime
        tmps = [d.humidity for d in data]
        plt.plot(dts, tmps, colors[cur_plot] + 'o-', label=data[0].location)
        cur_plot += 1
        cur_min = min(tmps)
        cur_max = max(tmps)
        if min(tmps) < t_min:
            t_min = cur_min
        if max(tmps) > t_max:
            t_max = cur_max

    plt.legend(loc='best')
    plt.title('House Humidity Over Last %d %s' % (num, units))
    ax = plt.gca()
    ax.xaxis.set_major_locator(days)
    ax.xaxis.set_minor_locator(hours)
    ax.xaxis.set_major_formatter(dayFmt)
    ax.xaxis.set_minor_formatter(hourFmt)
    ax.set_ylim(t_min - 5, t_max + 5)
    plt.xlabel('Datetime')
    plt.ylabel('Rel. Humidity (%)') 

    frame = plt.gcf()
    frame.autofmt_xdate()
    frame.set_size_inches([6,5])
    frame.savefig('/home/scott/programs/home_automation/home_automation/home_automation/homestatus/static/homestatus/recent_humids.png', dpi=80) 

    plt.clf()
    plt.cla()
    plt.close()


def get_current_temperature_list():
    #find all locations in house and get most recent temperature conversion for each to display as status
    all_temperature_locations = temperature.objects.order_by().values('location').distinct()
    cur_temperature_status = []  #location : temperature
    for loc_row in all_temperature_locations:
        cur_temp = temperature.objects.filter(location=loc_row['location']).order_by('-datetime')[0]
        if cur_temp:
            cur_temperature_status.append(cur_temp)
    return cur_temperature_status




def get_current_humidity_list():
    #find all locations in house and get most recent humidity conversion for each to display as status
    all_humidity_locations = humidity.objects.order_by().values('location').distinct()
    cur_humidity_status = []  #location : temperature
    for loc_row in all_humidity_locations:
        cur_temp = humidity.objects.filter(location=loc_row['location']).order_by('-datetime')[0]
        if cur_temp:
            cur_humidity_status.append(cur_temp)
    return cur_humidity_status



#this page will display all home status information on one page. To see just one type of info append /<type_of_data> to URL
def index(request):
    if baseboard_ctrl_thread.is_alive():
        pass 
   
    # get temperature data 
    cur_temperature_status = get_current_temperature_list() 

    #get humidity dat
    cur_humidity_status = get_current_humidity_list()

    #get light status information
    cur_light_status = light_status.objects.all()
    for lightobj in cur_light_status:
        temp_lid = baseboard_ctrl.reverse_lookup_outlet_light_id(int(lightobj.light_id))
        lightobj.light_id = temp_lid



    context = {
        'temperature_status' : cur_temperature_status,
        'humidity_status'   : cur_humidity_status,
        'light_status_list' : cur_light_status
        }
    return render(request, 'homestatus/index.html', context)
    

#code for temperature details page
def temperature_view(request):
    getunit = request.GET.get('units','days')
    if getunit not in ['days','hours']:
        getunit = 'hours'

    getnum = request.GET.get('num', '1')
    try:
        getnum = int(getnum)
    except:
        getnum = 24

    if getunit == 'hours':
        date_from = timezone.now() - datetime.timedelta(hours=getnum) 
    elif getunit == 'days':
        date_from = timezone.now() - datetime.timedelta(days=getnum) 
    else:
        date_from = timezone.now() - datetime.timedelta(hours=getnum)
        
    
    #temperature graph generation
    temperature_location_data = [] # list of querysets split by location for graphing
    cur_temperature_status = get_current_temperature_list() 
    for temp_obj in cur_temperature_status:
        temperature_location_data.append(temperature.objects.order_by('-datetime').filter(location=temp_obj.location,datetime__gte=date_from))
    generate_temperature_plot(temperature_location_data, getnum, getunit)

    #data for table
    temperature_list = []
    for l in temperature_location_data:
        temperature_list += l


    context = {'temperature_list' : temperature_list}
    return render(request, 'homestatus/temperature.html', context)


#code for humidity details page
def humidity_view(request):
    getunit = request.GET.get('units','days')
    if getunit not in ['days','hours']:
        getunit = 'hours'

    getnum = request.GET.get('num', '1')
    try:
        getnum = int(getnum)
    except:
        getnum = 1


    if getunit == 'hours':
        date_from = timezone.localtime(timezone.now()) - datetime.timedelta(hours=getnum) 
    elif getunit == 'days':
        date_from = timezone.localtime(timezone.now()) - datetime.timedelta(days=getnum) 
    else:
        date_from = timezone.localtime(timezone.now()) - datetime.timedelta(hours=getnum)


    cur_humidity_status = get_current_humidity_list()
    humidity_location_data = [] # list of querysets split by location for graphing
    for temp_obj in cur_humidity_status:
        humidity_location_data.append(humidity.objects.order_by('-datetime').filter(location=temp_obj.location,datetime__gte=date_from))
    generate_humidity_plot(humidity_location_data, num=getnum, units=getunit)

    #data for table
    humidity_list = []
    for l in humidity_location_data:
        humidity_list += l


    context = {'humidity_list' : humidity_list}
    return render(request, 'homestatus/humidity.html', context)



def light_cmd_view(request, light_id, brightness):
    try:
        light_id = int(light_id)
    except:
        light_id = baseboard_ctrl.OUTLET_LIGHT_ID_DEFS[light_id]
    
    if light_id == None:
        response = 'Failed'
    else:
        status = baseboard_ctrl_thread.send_light_cmd(lid=light_id, brightness=brightness) 
        if status:
            response = 'OK'
        else:
            response = 'Failed' 
    return HttpResponse(response)






