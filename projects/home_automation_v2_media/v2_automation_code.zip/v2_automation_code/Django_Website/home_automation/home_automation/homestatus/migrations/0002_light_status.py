# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('homestatus', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='light_status',
            fields=[
                ('id', models.AutoField(serialize=False, auto_created=True, verbose_name='ID', primary_key=True)),
                ('last_updated', models.DateTimeField(auto_now=True)),
                ('light_id', models.CharField(max_length=60)),
                ('brightness', models.PositiveSmallIntegerField()),
            ],
        ),
    ]
