import serial
import threading
import struct
import sys,os,inspect
from django.utils import timezone

cur_file_path = os.path.dirname(inspect.getfile(inspect.currentframe()))
parent_folder = os.path.abspath(os.path.join(cur_file_path, '..', '..'))
#if parent_folder not in sys.path:
#    sys.path.insert(0, parent_folder)

if __name__ != '__main__':
    import home_automation.homestatus.models as models   #import database models

### COMMAND DEFINITIONS ###
global PACKET_TYPE_DEFS
PACKET_TYPE_DEFS = {
    'TEMPERATURE_DATA'      : 1,
    'HUMIDITY_DATA'         : 2,
    'LIGHT_STATUS_DATA'     : 3,
    'THERMOSTAT_STATUS_DATA': 4,
    'POWER_USAGE_DATA'      : 5,
    'LOCK_STATUS_DATA'      : 6,
    'OUTLET_LIGHT_CONTROL'  : 7,
}


#packet source id number to location string mapping
# this is how the location will appear in the database
# CHANGE THIS TO CHANGE LOCATION FIELD IN DATABSE
global PACKET_SOURCE_ID_DEFS
PACKET_SOURCE_ID_DEFS = {
    'Base controller'       : 1,   #base controller
    'Bedroom'               : 2,   #device 1
    'Living Room'           : 3,   #device 2
    'Office'                : 4,   #device 3
}



#Translation of light id value into text description for database
global OUTLET_LIGHT_ID_DEFS 
OUTLET_LIGHT_ID_DEFS = {
    'Woods Outlet 1'        : 1,
    'Living Room Lamp'      : 2,
    'Woods Outlet 3'        : 3,
}



#True if the given value is a valid command type
def is_valid_packet_type(packet_type):
    if type(packet_type) == str:
        if packet_type in PACKET_TYPE_DEFS.keys():
            return True
    else:
        if packet_type in PACKET_TYPE_DEFS.values():
            return True 
    return False



#translate a command number to the string representation
def reverse_lookup_packet_type(packet_type):
    if packet_type in PACKET_TYPE_DEFS.values():
        for key, value in PACKET_TYPE_DEFS.items():
            if value == packet_type:
                return key
    return None


#translate a command source number to the string representation
def reverse_lookup_source_id(source_id):
    if type(source_id) != int:
        source_id = int(source_id)
    if source_id in PACKET_SOURCE_ID_DEFS.values():
        for key, value in PACKET_SOURCE_ID_DEFS.items():
            if value == source_id:
                return key
    return None


#translate a command source number to the string representation
def reverse_lookup_outlet_light_id(light_id):
    if light_id in OUTLET_LIGHT_ID_DEFS.values():
        for key, value in OUTLET_LIGHT_ID_DEFS.items():
            if value == light_id:
                return key
    return None



#class that wraps the host packet data
class HostPacket():

    def __init__(self):
        self.start_byte = 170
        self.packet_type = None
        self.data_length = None
        self.source_id = None
        self.dst_id = None

        #below here are packet specific fields

        #temperature
        self.temperature = None
        
        #humidity
        self.humidity = None

        #outlet/light control
        self.light_id = None
        self.brightness = None
        


    def __str__(self):
        if self.packet_type == 'TEMPERATURE_DATA':
            return 'packet_type=%s, location=%s, temperature=%d' % (self.packet_type, self.source_id, self.temperature)
        elif self.packet_type == 'HUMIDITY_DATA':
            return 'packet_type=%s, location=%s, humidity=%d' % (self.packet_type, self.source_id, self.humidity)
        elif self.packet_type == 'OUTLET_LIGHT_CONTROL':
            return 'packet_type=%s, light_id=%s, brightness=%d' % (self.packet_type, self.light_id, self.brightness)
            
    


"""
BaseboardCtrl class:   this class runs as a separate thread to the main server, and it's purpose is 
        essentially to populate the database with values from the sensors as they come in, and pass commands 
        from the server to the baseboard micro through UART.
"""
class BaseboardCtrl(threading.Thread):
    def __init__(self, comPort='/dev/ttyAMA0', baudrate=115200):
        threading.Thread.__init__(self, target=self.run)
        self.ser = serial.Serial(comPort, baudrate)
        self.queue = None                
        self.STOP_THREAD = False


    #function to send a packet to the baseboard micro. Called 
    #from the initiator of the coomand and not this thread
    def send_packet(self, packet):
        bytes_to_send = bytes( [packet.start_byte, PACKET_TYPE_DEFS[packet.packet_type], ((packet.data_length) >> 8) & 0xFF, packet.data_length & 0xFF, PACKET_SOURCE_ID_DEFS[packet.source_id], PACKET_SOURCE_ID_DEFS[packet.dst_id]])
        if packet.packet_type == 'TEMPERATURE_DATA':
            temp_C = self.temperature_F_to_C(packet.temperature)
            bytes_to_send += bytes([ temp_C >> 8 & 0xFF, temp_C & 0xFF])
        if packet.packet_type == 'HUMIDITY_DATA':
            bytes_to_send += bytes([packet.humidity & 0xFF])

        if packet.packet_type == 'OUTLET_LIGHT_CONTROL':
            bytes_to_send += bytes([packet.light_id & 0xFF, (packet.light_id >> 8) & 0xFF, packet.brightness & 0xFF]) 
        print (bytes_to_send)

        self.ser.write(bytes_to_send)


    def send_light_cmd(self, lid, brightness):
        brightness = int(brightness)

        temppacket = HostPacket()
        temppacket.packet_type = reverse_lookup_packet_type(7) 
        temppacket.data_length = 3
        temppacket.source_id = reverse_lookup_source_id(1)
        temppacket.dst_id = reverse_lookup_source_id(1)
        temppacket.brightness = brightness


        try:
            lid = int(lid)
            temppacket.light_id = lid
        except:
            try:
                temppacket.light_id = OUTLET_LIGHT_ID_DEFS[lid]
            except:
                return False

        self.send_packet(temppacket)
        
        #after sending packet, update in the database with light status
        self.update_light_status_database_entry(light_id=lid, brightness=brightness)

        return True

    # ------------- DATABASE ENTRY FUNCTIONS ---------------
    def add_temperature_database_entry(self, location, temperature):
        t = models.temperature(datetime=timezone.now(), location=location, temperature=temperature)
        t.save()

    # ------------- DATABASE ENTRY FUNCTIONS ---------------
    def add_humidity_database_entry(self, location, humidity):
        t = models.humidity(datetime=timezone.now(), location=location, humidity=humidity)
        t.save()

    #create light status entry if doesn't exist or update current entry
    def update_light_status_database_entry(self, light_id, brightness):
        L = models.light_status.objects.filter(light_id=light_id)
        if len(L) == 0:
            L = models.light_status(light_id=light_id, brightness=brightness)
            L.save()
        else:
            L = L[0]
            L.brightness = brightness
            L.save() 

    def temperature_C_to_F(self, temp_c):
        return round(float(temp_c) * 9 / 5 + 32)
    
    def temperature_F_to_C(self, temp_f):
        return round(((float(temp_f) - 32) * 5 / 9))

    #temperature is sent as an ADC value from the sensors convert to F temperature
    def temperature_adc_to_F(self, temp_adc):
        return round((float(temp_adc) * 165 / 16381 - 40) * 9/5 + 32) 


    def temperature_F_to_adc(self, temp_F):
        return (temp_F + 40) * 16381 / 165

    def get_and_parse_next_packet(self):
        DONE = False
        rx_packet = []
        frame_idx = 0
        self.tempPacket = HostPacket()

        while not DONE:
            if self.ser.inWaiting == 0:
                DONE = True
            byte = self.ser.read(1)
            if frame_idx == 0:
                byte = int.from_bytes(byte, byteorder='big')
                if byte == 170:
                    self.tempPacket.start_byte = byte
                    frame_idx += 1
                else:
                    frame_idx = 0
                    DONE = True
            elif frame_idx == 1:
                byte = int.from_bytes(byte, byteorder='big')
                if is_valid_packet_type(byte):
                    self.tempPacket.packet_type = reverse_lookup_packet_type(byte) 
                    frame_idx += 1
                else:
                    frame_idx = 0
                    DONE = True
            elif frame_idx == 2:
                self.tempPacket.data_length = int.from_bytes(byte, byteorder='big')
                frame_idx += 1
            elif frame_idx == 3:
                self.tempPacket.data_length = (self.tempPacket.data_length << 8) | (int.from_bytes(byte, byteorder='big') & 0xFF)
                frame_idx += 1
            elif frame_idx == 4:
                self.tempPacket.source_id = reverse_lookup_source_id(int.from_bytes(byte, byteorder='big'))
                frame_idx += 1
            elif frame_idx == 5:
                self.tempPacket.dst_id = reverse_lookup_source_id(int.from_bytes(byte, byteorder='big'))
                frame_idx += 1
            
            #####  #TEMPERATURE_DATA  #####
            elif self.tempPacket.packet_type == 'TEMPERATURE_DATA':
                if frame_idx == 6:
                    self.tempPacket.temperature = byte
                    frame_idx += 1
                elif frame_idx == 7:
                    self.tempPacket.temperature += byte
                    self.tempPacket.temperature = struct.unpack('>h', self.tempPacket.temperature)[0] 
                    print('temperature_adc = ' + str(self.tempPacket.temperature))
                    self.tempPacket.temperature = self.temperature_adc_to_F(self.tempPacket.temperature) 
                    DONE = True
                    return self.tempPacket
            #### HUMIDITY DATA   ######
            elif self.tempPacket.packet_type == 'HUMIDITY_DATA':
                self.tempPacket.humidity = int.from_bytes(byte, byteorder='big')
                DONE = True
                return self.tempPacket


            #### LIGHT/OUTLET CONTROL/STATUS DATA ####
            elif self.tempPacket.packet_type == 'OUTLET_LIGHT_CONTROL':
                if frame_idx == 6:
                    self.tempPacket.light_id = int.from_bytes(byte, byteorder='big')
                    frame_idx += 1
                elif frame_idx == 7:
                    self.tempPacket.light_id = self.tempPacket.light_id | (int.from_bytes(byte, byteorder='big') >> 8)
                    self.tempPacket.light_id = reverse_lookup_outlet_light_id(self.tempPacket.light_id)
                    frame_idx += 1
                elif frame_idx == 8:
                    self.tempPacket.brightness = int.from_bytes(byte, byteorder='big')
                    DONE = True
                    return self.tempPacket
            
            else:
                frame_idx = 0
 
        return None


    def run(self):
        try:
            while True:
                packet = self.get_and_parse_next_packet()
                
                if self.STOP_THREAD:
                    break
                
                if packet == None:
                    continue

                if packet.packet_type == 'TEMPERATURE_DATA':
                    self.add_temperature_database_entry(location=packet.source_id, temperature=packet.temperature)
                elif packet.packet_type == 'HUMIDITY_DATA':
                    self.add_humidity_database_entry(location=packet.source_id, humidity=packet.humidity)
                elif packet.packet_type == 'OUTLET_LIGHT_CONTROL' or packet.packet_type == 'OUTLET_LIGHT_STATUS':
                    self.update_light_status_database_entry(light_id=packet.light_id, brightness=packet.brightness)
                print(packet)
                

        except KeyboardInterrupt:
            pass
        except:
            raise



if __name__ == '__main__':
    b = BaseboardCtrl()
    b.start()

    testpacket = HostPacket()
    testpacket.packet_type = reverse_lookup_packet_type(7) 
    testpacket.data_length = 3
    testpacket.source_id = reverse_lookup_source_id(1)
    testpacket.dst_id = reverse_lookup_source_id(1)
    testpacket.light_id = OUTLET_LIGHT_ID_DEFS['Living Room Lamp']
    testpacket.brightness = 0
    b.send_packet(testpacket)

