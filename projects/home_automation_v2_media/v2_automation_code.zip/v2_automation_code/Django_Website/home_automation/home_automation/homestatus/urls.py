from django.conf.urls import url
from . import views


urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^temperature', views.temperature_view, name='temperature'),
    url(r'^humidity', views.humidity_view, name='humidity'),
    url(r'^lightcmd/(?P<light_id>[0-9a-zA-z ]+)/(?P<brightness>[0-9]+)', views.light_cmd_view, name='lightcmd'),
]

