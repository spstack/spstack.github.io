# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='humidity',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('datetime', models.DateTimeField(auto_now=True)),
                ('location', models.CharField(max_length=40)),
                ('humidity', models.PositiveSmallIntegerField()),
            ],
        ),
        migrations.CreateModel(
            name='temperature',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('datetime', models.DateTimeField(auto_now=True)),
                ('location', models.CharField(max_length=40)),
                ('temperature', models.IntegerField()),
            ],
        ),
    ]
