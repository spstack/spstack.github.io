/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

#if defined(__XC)
    #include <xc.h>         /* XC8 General Include File */
#elif defined(HI_TECH_C)
    #include <htc.h>        /* HiTech General Include File */
#endif

#include <stdint.h>        /* For uint8_t definition */
#include <stdbool.h>       /* For true/false definition */

#include "system.h"        /* System funct/params, like osc/peripheral config */
#include "user.h"          /* User funct/params, such as InitApp */

/******************************************************************************/
/* User Global Variable Declaration                                           */
/******************************************************************************/

/* i.e. uint8_t <variable_name>; */
char PREV_REC_BUTTON = 1;
char PREV_PLAY_BUTTON = 1;



/******************************************************************************/
/* Main Program                                                               */
/******************************************************************************/
void main(void)
{

    
    unsigned int i;
    unsigned char temp_ir_command;
    //unsigned char first_rec_pass = 0;   //1 if rec has just been initiated
    /* Configure the oscillator for the device */
    ConfigureOscillator();

    /* Initialize I/O and Peripherals for application */
    InitApp();

    LATAbits.LATA0 = 0;   //TEST to see whether device is constantly resetting
    LATAbits.LATA2 = 0;
    LATAbits.LATA1 = 0;
    //LATBbits.LATB3 = 0; //turn off all outputs initially

    COMMAND_OVERFLOW = 0;
    INDEX = 0;   //index into the current command
    REC = 0;    //recording in progress
    REC_PASS = 0; //the number of IR 'packets' that have been recorded
    WAITING_FOR_REC = 0; //1 if waiting for first pulse from IR reciever
    PLAY = 0;   //playback in progress
    PLAY_PASS = 0; //the number of times the sequence has been played back
    COMMAND_DONE = 1;  //command has completed recording
    PLAY_DONE = 0;     //command is done being played back
    TEMP_COMMAND_SIZE = 0;
    CURRENT_COMMAND = 0; //default command is the power command
    RF_FIRST_EDGE = TRUE;
    RF_COMMAND_DONE = FALSE;

    load_command(CURRENT_COMMAND);

    while(1)
    {
        //----------------------BUTTON INPUTS-----------------------
        //check rec button
        if((PORTAbits.RA3 == 0) && (PREV_REC_BUTTON == 1)) {
            REC = 1;

            CCP1CONbits.CCP1M = 4; //set up CCP for recording
            WAITING_FOR_REC = 1; //now waiting for the first pulse
            LATAbits.LATA0 = 1;  //turn on REC LED

            CCP2CONbits.DC2B0 = 0;  //init IR output to 0 by turning off PWM
            CCPR2L = 0x00;
            IR_STAT = 0;
            //LATBbits.LATB3 = 0; //initialize IR output to 0
            
            INDEX = 0;
            CCP1IE = 1;
            TMR1 = 0;
        } 
        PREV_REC_BUTTON = PORTAbits.RA3;


        //check play button
        if((PORTAbits.RA4 == 0) && (PREV_PLAY_BUTTON == 1)) {
            if(!REC && !PLAY) {
                PLAY = 1;

                INDEX = 0;        
                CCP1CONbits.CCP1M = 0x0A; //Compare mode set output high and go low on match
                CCPR1H = (TEMP_COMMAND[0] >> 8); //init the compare reg with first val
                CCPR1L = (TEMP_COMMAND[0] & 0x00FF);
                TMR1 = 0;
                LATBbits.LATB3 = 0; //initialize IR output to 1 and wait a bit
                for(i=0;i<500;i++);
                
                LATAbits.LATA1 = 1; //turn on play LED
                CCP1IE = 1;
            } else {
                //stop recording ir command
                REC_PASS = 0;
                INDEX = 0;
                REC = 0;
                LATAbits.LATA0 = 0; //turn off rec LED
            }
        }
        PREV_PLAY_BUTTON = PORTAbits.RA4;


        //check change command button
        /*if((PORTAbits.RA2 == 0) && (PREV_PLAY_BUTTON == 1)) {
            if(!PLAY && !REC) {
                CURRENT_COMMAND = (CURRENT_COMMAND + 1) % NUM_COMMANDS;

                //load the command into RAM
                if(!load_command(CURRENT_COMMAND)) {
                    //blink to show loading error
                    LATAbits.LATA0 = 0;
                    for(i=0;i<10000;i++);
                    LATAbits.LATA0 = 1;
                    for(i=0;i<10000;i++);
                    LATAbits.LATA0 = 0;
                    for(i=0;i<10000;i++);
                    LATAbits.LATA0 = 1;
                    for(i=0;i<10000;i++);
                    LATAbits.LATA0 = 0;
                }
            }
        }
        PREV_PLAY_BUTTON = PORTAbits.RA2;
        */



        //-------------------RECORDING LOGIC---------------------------
       
        if (COMMAND_DONE) {
            COMMAND_DONE = 0;
            //ignore the first packet that has been received (because it's
            //probably only half of a packet) and
            if(REC_PASS > 0) {
                TEMP_COMMAND_SIZE = INDEX;
                REC_PASS = 0;
                INDEX = 0;
                REC = 0;
                LATAbits.LATA0 = 0; //turn off rec LED
                //TODO: maybe save command to flash...
            } else {
                REC_PASS++;
                WAITING_FOR_REC = 1;
                CCP1IE = 1;
            }
        }

        if(COMMAND_OVERFLOW) {
            COMMAND_OVERFLOW = 0;
            INDEX = 0;
            REC_PASS = 0;
            REC = 0;

             //blink to show overflow
            LATAbits.LATA0 = 0;
            for(i=0;i<20000;i++);
            LATAbits.LATA0 = 1;
            for(i=0;i<20000;i++);
            LATAbits.LATA0 = 0;
            for(i=0;i<20000;i++);
            LATAbits.LATA0 = 1;
            for(i=0;i<20000;i++);
            LATAbits.LATA0 = 0;
        }


        //------------------PLAY LOGIC -------------------------------

        if (PLAY_DONE) {
            PLAY_DONE = 0;

            //if the command has been played 3 times, quit else play again
            if(PLAY_PASS == 3) {
                PLAY = 0;
                LATAbits.LATA1 = 0; //turn off playing LED

                //LATBbits.LATB3 = 0;
                CCP2CONbits.DC2B = 0;   //turn off IR transmitter
                IR_STAT = 0;

                INDEX = 0;
                PLAY_PASS = 0;
            } else {
                //LATBbits.LATB3 = 0; //turn off transmitter
                CCP2CONbits.DC2B = 0;   //turn off transmitter
                IR_STAT = 0;

                //wait for a couple ms before sending next command
                for(i=0;i<24700;i++);

                PLAY_PASS++;
                INDEX = 0;
                CCPR1H = (TEMP_COMMAND[0] >> 8); //init the compare reg with first val
                CCPR1L = (TEMP_COMMAND[0] & 0x00FF);
                TMR1 = 0;
                CCP1IE = 1;
            }
        }

        //----------------------------RF COMMAND LOGIC------------------------
        if (RF_COMMAND_DONE) {
            RF_COMMAND_DONE = FALSE;
            temp_ir_command = get_rf_command();
            if (temp_ir_command != 255) {
                load_command(temp_ir_command);
                clear_rf_command();
                //start playing requested IR command
                PLAY = 1;
                INDEX = 0;
                CCP1CONbits.CCP1M = 0x0A; //Compare mode set output high and go low on match
                CCPR1H = (TEMP_COMMAND[0] >> 8); //init the compare reg with first val
                CCPR1L = (TEMP_COMMAND[0] & 0x00FF);
                TMR1 = 0;
                LATBbits.LATB3 = 0; //initialize IR output to 1 and wait a bit
                for(i=0;i<50;i++);

                LATAbits.LATA1 = 1; //turn on play LED
                CCP1IE = 1;
            } else {
                /* Blink if header matches, but code not recognized
                LATAbits.LATA0 = 0;
                for(i=0;i<20000;i++);
                LATAbits.LATA0 = 1;
                for(i=0;i<20000;i++);
                LATAbits.LATA0 = 0;
                for(i=0;i<20000;i++);
                LATAbits.LATA0 = 1;
                for(i=0;i<20000;i++);
                LATAbits.LATA0 = 0;
                */
            }
            
        }

        
        //done main loop
    }

}

