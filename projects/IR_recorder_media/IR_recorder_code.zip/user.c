/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

#if defined(__XC)
    #include <xc.h>         /* XC8 General Include File */
#elif defined(HI_TECH_C)
    #include <htc.h>        /* HiTech General Include File */
#endif

#include <stdint.h>         /* For uint8_t definition */
#include <stdbool.h>        /* For true/false definition */

#include "user.h"

/******************************************************************************/
/* User Functions                                                             */
/******************************************************************************/

/* <Initialize variables in user.h and insert code for user algorithms.> */

void InitApp(void)
{
    //Set up GPIO Pins
    //TRISBbits.TRISB3 = 0; //output of IR transmitter
    TRISAbits.TRISA7 = 1;   //PWM output for IR transmitter (set to 1 to disable output driver as per datasheet)
    TRISBbits.TRISB0 = 1; //input for IR receiver / CCP1

    TRISBbits.TRISB5 = 0;  //TX for UART
    TRISBbits.TRISB2 = 1;  //RX for UART
    TRISBbits.TRISB1 = 1;  // IOC for radio commands

    TRISAbits.TRISA1 = 0; //PLAY LED indicator
    TRISAbits.TRISA0 = 0; //REC LED indicator

    //TRISAbits.TRISA2 = 1; // change command button
    TRISAbits.TRISA3 = 1; // REC command button
    TRISAbits.TRISA4 = 1; // PLAY command button

    APFCON1bits.TXCKSEL = 1; //set TX to pin RB5
    APFCON0bits.RXDTSEL = 1; //set RX to pin RB2
    APFCON0bits.CCP1SEL = 1; //set CCP1 pin to B0
    APFCON0bits.CCP2SEL = 1; //set CCP2 pin to RA7

    ANSELB = 0; //make sure AN function not used for pins
    ANSELA = 0;
    

    //Set up UART
    TXSTAbits.TXEN = 1;
    TXSTAbits.SYNC = 0;
    TXSTAbits.BRGH = 1;  //high speed baud rate generator
    RCSTAbits.SPEN = 1;
    RCSTAbits.CREN = 1;
    TXSTAbits.TRMT = 1;
    BAUDCONbits.BRG16 = 0;
    SPBRGH = 0;
    SPBRGL = 25;    //baud rate of 19200...hopefully


    //set up timer1 for IR record (CCP)and playback
    T1CONbits.TMR1CS = 0;  //timer source clock is instruction clock (FOSC/4 = 4MHz)
    T1CONbits.T1CKPS = 0;  //time prescalar = 1:1 8MHz = 4MHz
    T1CONbits.TMR1ON = 1;  //turn timer on
    //set up ccp for IR record function
    CCP1CONbits.CCP1M = 4; //capture on every falling edge (set to 5 to capture on every rising edge

    //set up PWM output for IR transmitting
    T2CONbits.T2CKPS = 1; //prescalar of 4 (FOSC/4 = 4MHz)
    T2CONbits.TMR2ON = 1; // turn timer 2 on
    PR2 = 25;            //set period to 38kHz (.0000263s)
    CCPTMRSbits.C2TSEL = 0; //CCP2 is based off of timer 2
    CCP2CONbits.CCP2M = 12; //set CCP2 to PWM mode
    CCP2CONbits.DC2B = 0;   //set the LSb's of the Duty Cycle
    CCPR2L = 0;          //set lower 8 bits of duty cycle reg. (at 50% duty cycle)
    
    //set up interrupt on change on RB1 and timer4 for receiving RF commands
    IOCBNbits.IOCBN1 = 0;   //interrupt on 1->0 triansition
    IOCBPbits.IOCBP1 = 1;   //interrupt on 0->1 transition 
    T4CONbits.T4CKPS = 3; //1:64 prescalar = .016ms period
    T4CONbits.TMR4ON = 1;

    /* Enable interrupts */
    CCP1IE = 1;
    TMR1IE = 1;
    //RCIE = 1;     //enable RX interrupts
    PIE1bits.CCP1IE = 0;  //disable T1 compare interrupt
    PIE1bits.TMR1IE = 1;  //enable T1 overflow interrupt

    PIE3bits.TMR4IE = 1; //enable timer 4 interrupts for measuring RF command pulses

    PIE1bits.TMR2IE = 0;  //disable T2 interrupt
    TMR2IF = 0;

    TRISAbits.TRISA7 = 0;
    INTCONbits.GIE = 1;  //enable global interrupts
    INTCONbits.PEIE = 1; //enable peripheral interrupts
    INTCONbits.IOCIE = 1; //enable interrupt on change interrupts (used by RF commands)
    ei();  //enable interrupts!!
}





//FUNCTIONS TO IMPLEMENT CIRCULAR BUFFER
int BUFF_push(BUFFER* buff, char c) {
  if((buff->tail + 1) % MAX_BUFFSIZE == buff->head) {
    return BUFF_FULL;
  } else {
    buff->data[buff->tail] = c;
    buff->tail = (buff->tail + 1) % MAX_BUFFSIZE;
  }
  return BUFF_NORMAL;
}

char BUFF_pop(BUFFER* buff) {
  char c = -1;
  if(buff->head == buff->tail) {
    return BUFF_EMPTY;
  } else {
    c = buff->data[buff->head];
    buff->head = (buff->head + 1) % MAX_BUFFSIZE;
  }
  return c;
}

int BUFF_status(BUFFER* buff) {
  if(buff->head == buff->tail) {
    return BUFF_EMPTY;
  } else if ((buff->tail + 1) % MAX_BUFFSIZE == buff->head) {
    return BUFF_FULL;
  } else {
    return BUFF_NORMAL;
  }
}


void clear_temp_command() {
    unsigned int i;

    for(i=0;i<MAX_COMMAND_LENGTH;i++) {
        TEMP_COMMAND[i] = 0;
    }
    TEMP_COMMAND_SIZE = 0;

    return;
}

char load_command(unsigned int command) {
    unsigned int i = 0;

    while (IR_COMMANDS[command][i] != 0 || i >= MAX_COMMAND_LENGTH) {
        TEMP_COMMAND[i] = IR_COMMANDS[command][i];
        i++;
    }

    /*
    switch(command) {
        case(POWER_PANASONIC_CMD):
            while(POWER_PANASONIC[i] != 0 || i >= MAX_COMMAND_LENGTH) {
                TEMP_COMMAND[i] = POWER_PANASONIC[i];
                i++;
            }
            break;
        case(VOL_UP_PANASONIC_CMD):
            while(VOL_UP_PANASONIC[i] != 0 || i >= MAX_COMMAND_LENGTH) {
                TEMP_COMMAND[i] = VOL_UP_PANASONIC[i];
                i++;
            }
            break;
        case(VOL_DOWN_PANASONIC_CMD):
            while(VOL_DOWN_PANASONIC[i] != 0 || i >= MAX_COMMAND_LENGTH) {
                TEMP_COMMAND[i] = VOL_DOWN_PANASONIC[i];
                i++;
            }
            break;
        case(CHAN_UP_PANASONIC_CMD):
            while(CHAN_UP_PANASONIC[i] != 0 || i >= MAX_COMMAND_LENGTH) {
                TEMP_COMMAND[i] = CHAN_UP_PANASONIC[i];
                i++;
            }
            break;
        case(CHAN_DOWN_PANASONIC_CMD):
            while(CHAN_DOWN_PANASONIC[i] != 0 || i >= MAX_COMMAND_LENGTH) {
                TEMP_COMMAND[i] = CHAN_DOWN_PANASONIC[i];
                i++;
            }
            break;
        default:
            return 0;

    }
    */

    if(i >= MAX_COMMAND_LENGTH) {
        return 0;
    }
    TEMP_COMMAND_SIZE = i;
    return 1;
    
}

void clear_rf_command() {
    unsigned int i;
    for(i=0;i<16;i++) {
        RF_COMMAND[i] = 0;
    }
    RF_FIRST_EDGE = TRUE;
}

char get_rf_command() {
    unsigned int i = 0;
    unsigned int j = 0;

    //check header to make sure it matches
    for(i=0;i<8;i++) {
        if(i < 8) {
            if (RF_COMMAND[i] != RFCMD_TV_POWER[i]) {
                return 255;
            }
        }
    }

    //now match rest of command to one if the stored commands
    for(i=0;i<NUM_RF_COMMANDS;i++) {
        for(j=8;j<16;j++) {
            if (RF_COMMAND[j] != RF_COMMANDS[i][j]) {
                break;
            } else if (j == 15) {
                if (i < NUM_IR_COMMANDS) {
                    return i; //return command number if they match!
                } else {
                    return 255;
                }
            }
        }
    }

    //should't really get here unless header matches but the rest doesn't
    //match any of the stored commands
    return 255;
}