/******************************************************************************/
/*Files to Include                                                            */
/******************************************************************************/

#if defined(__XC)
    #include <xc.h>         /* XC8 General Include File */
#elif defined(HI_TECH_C)
    #include <htc.h>        /* HiTech General Include File */
#endif

#include <stdint.h>         /* For uint8_t definition */
#include <stdbool.h>        /* For true/false definition */
#include "user.h"

/******************************************************************************/
/* Interrupt Routines                                                         */
/******************************************************************************/

/* Baseline devices don't have interrupts. Note that some PIC16's 
 * are baseline devices.  Unfortunately the baseline detection macro is 
 * _PIC12 */
//#ifndef _PIC12

void interrupt isr(void)
{
    /* This code stub shows general interrupt handling.  Note that these
    conditional statements are not handled within 3 seperate if blocks.
    Do not use a seperate if block for each interrupt flag to avoid run
    time errors. */

    unsigned int temp = 0;
    unsigned int i = 0;

    if(CCP1IE && CCP1IF) {
        TMR1 = 0;
        //LATAbits.LATA0 = 1;

        //only continue if recording is in progress...
        if (REC) {
            //if it's not the first pulse, record the length of the pulse
            WAITING_FOR_REC = 0;
            if (INDEX != 0) {
                temp = (CCPR1H << 8);
                temp |= CCPR1L;
                TEMP_COMMAND[INDEX] = temp;
            }

            CCP1CONbits.CCP1M0 ^= 1;  //toggle the capture mode (every rising or every falling edge)
            INDEX++;

            if(INDEX >= (MAX_COMMAND_LENGTH)) {
                COMMAND_OVERFLOW = 1;
                CCP1IE = 0;
            }
        }

        //if playing back command
        else if(PLAY) {
            //toggle the PWM on/off
            if(IR_STAT == 1) {
                //turn off PWM
                CCP2CONbits.DC2B = 0;   //set the LSb's of the Duty Cycle
                CCPR2L = 0;          //set lower 8 bits of duty cycle reg. (at 50% duty cycle)
                IR_STAT = 0;
            } else {
                //turn on PWM
                CCP2CONbits.DC2B = 1;   //set the LSb's of the Duty Cycle
                CCPR2L = (53 >> 2);          //set lower 8 bits of duty cycle reg. (at 50% duty cycle)
                IR_STAT = 1;
            }

            //LATBbits.LATB3 ^= 1;  //toggle the IR transmitter
            INDEX++;

            CCPR1H = (TEMP_COMMAND[INDEX] >> 8); //init the compare reg with first val
            CCPR1L = (TEMP_COMMAND[INDEX] & 0x00FF);

            if (INDEX == (MAX_COMMAND_LENGTH-1) || (INDEX >= TEMP_COMMAND_SIZE)) {
                PLAY_DONE = 1;
                CCP1IE = 0;
            }
        }


        //TMR1 = 0;  //reset the timer
        CCP1IF = 0;
    }

    else if (TMR1IE && TMR1IF) {
        TMR1IF = 0;
        TMR1 = 0;
        
        //if we are waiting for the first pulse ignore...
        if (!WAITING_FOR_REC && REC) {
            COMMAND_DONE = 1;  //if the timer overflows, the command has completed
            CCP1IE = 0;
        }
    }

    //handle interrupts that shouldn't happen often and have no real meaning
    else if (TMR2IF) {
        TMR2IF = 0;
    }
    else if (CCP2IF) {
        CCP2IF = 0;
    }


    // The timer 4 overflow interrupt
    else if (TMR4IF) {
        TMR4IF = 0;
        TMR4 = 0;
        //clear the current rf command because timer timed out
        //clear_rf_command(); //clear the current command because the timer timed out
        RF_FIRST_EDGE = TRUE;
        RF_COMMAND_POS = 0;
    }

    //Interrupt on change interrupt for receiving RF command
    else if (IOCIF) {
        IOCBF = 0;    //clear the interrupt flags
        
        //if not in the middle of playing/recording and only measure positive pulses
        //not the space between them (so only continue if the transition was 1->0)
        if (!REC && !PLAY) {
            //if it's not the first edge, record pulse width
                
            if ((!RF_COMMAND_DONE)  && (IOCBNbits.IOCBN1 == 1)) {
                temp = TMR4;  //first get the timer4 (pulse width) value
                if (temp >= RF_S_PULSE_WIDTH_MIN && temp <= RF_S_PULSE_WIDTH_MAX) {
                    RF_COMMAND[RF_COMMAND_POS] = 'S';
                    RF_COMMAND_POS += 1;
                    if (RF_COMMAND_POS == 16) {
                        RF_COMMAND_DONE = TRUE;
                    }
                } else if (temp >= RF_L_PULSE_WIDTH_MIN && temp <= RF_L_PULSE_WIDTH_MAX) {
                    RF_COMMAND[RF_COMMAND_POS] = 'L';
                    RF_COMMAND_POS += 1;
                    if (RF_COMMAND_POS == 16) {
                        RF_COMMAND_DONE = TRUE;
                    }
                } else {
                    RF_FIRST_EDGE = TRUE;
                    RF_COMMAND_POS = 0;
                    //clear_rf_command();
                }

            } else {
                //RF_FIRST_EDGE = FALSE;
            }
        }

        //flip what transition IOC interrupts on
        if (IOCBNbits.IOCBN1 == 1) {
            IOCBNbits.IOCBN1 = 0; //interrupt on 1->0 triansition
            IOCBPbits.IOCBP1 = 1;   //interrupt on 0->1 transition
        }
        else {
            IOCBNbits.IOCBN1 = 1; //interrupt on 1->0 triansition
            IOCBPbits.IOCBP1 = 0;   //interrupt on 0->1 transition
        }
        TMR4 = 0; //reset the timer for next time around
    }

    else {
        PIR1 = 0;
        PIR2 = 0;
        PIR3 = 0;
        PIR4 = 0;

    }
}
//#endif


